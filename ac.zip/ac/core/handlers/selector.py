import os
import json
import asyncio
import time
import shutil
from urllib.parse import quote
from telethon import events
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DOWNLOAD_FOLDER = os.path.join(BASE_DIR, "downloads")
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

selection_start = {}
selection_end = {}
multi_select_start_id = {}
multi_select_end_id = {}

def get_total_downloads_size():
    total = 0
    if not os.path.exists(DOWNLOAD_FOLDER):
        return 0
    for f in os.listdir(DOWNLOAD_FOLDER):
        f_path = os.path.join(DOWNLOAD_FOLDER, f)
        if f != "files_meta.json" and os.path.isfile(f_path):
            total += os.path.getsize(f_path)
    return total

def format_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes < 1024.0:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.1f} TB"

async def download_and_get_link(client, message, chat_id):
    try:
        file_path = await message.download_media(file=DOWNLOAD_FOLDER)
        if not file_path:
            return None, "❌ دانلود ناموفق"
        
        file_name = os.path.basename(file_path)
        file_size = os.path.getsize(file_path) / 1024
        
        meta_file = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")
        meta = {}
        if os.path.exists(meta_file):
            try:
                with open(meta_file, "r") as f:
                    meta = json.load(f)
            except:
                pass
        meta[file_name] = datetime.now().isoformat()
        with open(meta_file, "w") as f:
            json.dump(meta, f, indent=4)
        
        PUBLIC_HOST = os.getenv("PUBLIC_HOST", "185.183.33.91")
        PORT = os.getenv("PORT", "8800")
        encoded_filename = quote(file_name)
        download_link = f"http://{PUBLIC_HOST}:{PORT}/files/{encoded_filename}"
        
        return {"name": file_name, "size_kb": file_size, "link": download_link}, None
        
    except Exception as e:
        return None, str(e)

def register_selector(client, db):
    
    @client.on(events.NewMessage(pattern=r'\.cs$'))
    async def select_start(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if not event.is_reply:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ روی یه پیام ریپلای کن تا شروع بازه مشخص بشه.")
            return
        replied = await event.get_reply_message()
        chat_id = event.chat_id
        selection_start[chat_id] = replied.id
        if chat_id in selection_end:
            del selection_end[chat_id]
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"✅ شروع بازه ثبت شد: msg {replied.id}")

    @client.on(events.NewMessage(pattern=r'\.ce$'))
    async def select_end(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if not event.is_reply:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ روی یه پیام ریپلای کن تا پایان بازه مشخص بشه.")
            return
        replied = await event.get_reply_message()
        chat_id = event.chat_id
        if chat_id not in selection_start:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ اول با `.cs` شروع بازه رو مشخص کن.")
            return
        start_id = selection_start[chat_id]
        end_id = replied.id
        if start_id > end_id:
            start_id, end_id = end_id, start_id
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"🔄 در حال جمع‌آوری پیام‌های {start_id} تا {end_id}...")
        messages = await client.get_messages(chat_id, min_id=start_id, max_id=end_id, reverse=True, limit=500)
        if not messages:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ هیچ پیامی در این بازه پیدا نشد.")
            return
        full_text = f"📝 **بازه پیام‌ها**\n🔹 شروع: msg {start_id}\n🔸 پایان: msg {end_id}\n📊 تعداد: {len(messages)}\n" + "=" * 40 + "\n\n"
        for i, msg in enumerate(messages, 1):
            sender = await msg.get_sender()
            sender_name = sender.first_name if sender else "Unknown"
            if sender.username:
                sender_name += f" (@{sender.username})"
            msg_text = msg.text or "📎 [بدون متن]"
            if len(msg_text) > 200:
                msg_text = msg_text[:200] + "..."
            full_text += f"{i}. **{sender_name}**:\n{msg_text}\n\n"
        try:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), full_text)
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"✅ {len(messages)} پیام از بازه انتخاب‌شده ارسال شد.")
        except Exception as e:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"❌ خطا: {e}")
        del selection_start[chat_id]
        if chat_id in selection_end:
            del selection_end[chat_id]

    @client.on(events.NewMessage(pattern=r'\.ss$'))
    async def multi_select_start(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if not event.is_reply:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ روی اولین پیام حاوی فایل ریپلای کن تا شروع بازه مشخص بشه.")
            return
        replied = await event.get_reply_message()
        chat_id = event.chat_id
        multi_select_start_id[chat_id] = replied.id
        if chat_id in multi_select_end_id:
            del multi_select_end_id[chat_id]
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"✅ شروع بازه برای سیو چندگانه ثبت شد: msg {replied.id}")

    @client.on(events.NewMessage(pattern=r'\.se$'))
    async def multi_select_end(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if not event.is_reply:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ روی آخرین پیام حاوی فایل ریپلای کن تا پایان بازه مشخص بشه.")
            return
        replied = await event.get_reply_message()
        chat_id = event.chat_id
        if chat_id not in multi_select_start_id:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ اول با `.ss` شروع بازه رو مشخص کن.")
            return
        start_id = multi_select_start_id[chat_id]
        end_id = replied.id
        if start_id > end_id:
            start_id, end_id = end_id, start_id
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"🔄 در حال بررسی پیام‌های {start_id} تا {end_id}...")
        messages = await client.get_messages(chat_id, min_id=start_id, max_id=end_id, reverse=True, limit=500)
        if not messages:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ هیچ پیامی در این بازه پیدا نشد.")
            del multi_select_start_id[chat_id]
            return
        media_messages = [msg for msg in messages if msg.media]
        if not media_messages:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ هیچ فایلی (عکس/ویدیو/سند) در این بازه پیدا نشد.")
            del multi_select_start_id[chat_id]
            return
        msg_text = f"📁 **{len(media_messages)} فایل در این بازه پیدا شد:**\n━━━━━━━━━━━━━━━━━━━━━\n"
        file_list = []
        for i, msg in enumerate(media_messages, 1):
            file_name = None
            if msg.file:
                file_name = msg.file.name
            if not file_name and msg.media:
                if msg.photo:
                    file_name = f"photo_{msg.id}.jpg"
                elif msg.video:
                    file_name = f"video_{msg.id}.mp4"
                elif msg.document:
                    file_name = f"document_{msg.id}.file"
                else:
                    file_name = f"media_{msg.id}.file"
            file_list.append({"msg": msg, "name": file_name, "index": i})
            size = msg.file.size if msg.file else 0
            size_human = format_size(size) if size else "نامشخص"
            msg_text += f"{i}. `{file_name}`\n   📦 {size_human}\n\n"
        msg_text += f"━━━━━━━━━━━━━━━━━━━━━\n✅ **روی این پیام ریپلای کنید و شماره فایل‌های مورد نظر را بنویسید.**\nمثال: `1 3 5` یا `all` برای همه فایل‌ها."
        list_msg = await client.send_message(int(os.getenv('OWNER_ID', 0)), msg_text)
        list_msg_id = list_msg.id
        
        @client.on(events.NewMessage(from_users=int(os.getenv('OWNER_ID', 0))))
        async def selection_handler(resp_event):
            if not resp_event.message.reply_to:
                return
            if resp_event.message.reply_to.reply_to_msg_id != list_msg_id:
                return
            choice = resp_event.message.text.strip().lower()
            if choice == 'all':
                selected_indices = list(range(1, len(file_list) + 1))
            else:
                try:
                    selected_indices = [int(x.strip()) for x in choice.split() if x.strip().isdigit()]
                except:
                    await resp_event.reply("❌ شماره‌های نامعتبر. لطفاً اعداد را با فاصله وارد کنید.")
                    return
            if not selected_indices:
                await resp_event.reply("❌ هیچ شماره معتبری انتخاب نشد.")
                return
            valid_indices = [i for i in selected_indices if 1 <= i <= len(file_list)]
            if not valid_indices:
                await resp_event.reply(f"❌ شماره‌ها باید بین ۱ تا {len(file_list)} باشند.")
                return
            selected_files = [file_list[i-1] for i in valid_indices]
            await resp_event.reply(f"📥 در حال دانلود {len(selected_files)} فایل...\n⏳ این کار ممکن است چند دقیقه طول بکشد.")
            results = []
            for idx, file_item in enumerate(selected_files, 1):
                await resp_event.reply(f"🔄 در حال دانلود فایل {idx}/{len(selected_files)}: `{file_item['name']}`")
                result, error = await download_and_get_link(client, file_item['msg'], resp_event.chat_id)
                if result:
                    results.append(result)
                else:
                    results.append({"name": file_item['name'], "error": error})
            success_count = len([r for r in results if "link" in r])
            failed_count = len([r for r in results if "error" in r])
            final_msg = f"✅ **دانلود {success_count} فایل با موفقیت انجام شد.**\n"
            if failed_count > 0:
                final_msg += f"❌ {failed_count} فایل ناموفق.\n"
            final_msg += f"━━━━━━━━━━━━━━━━━━━━━\n\n"
            for r in results:
                if "link" in r:
                    final_msg += f"📁 `{r['name']}`\n📦 {r['size_kb']:.1f} KB\n🔗 {r['link']}\n\n"
                else:
                    final_msg += f"❌ `{r['name']}`: {r.get('error', 'نامشخص')}\n\n"
            await client.send_message(int(os.getenv('OWNER_ID', 0)), final_msg)
            del multi_select_start_id[chat_id]
            if chat_id in multi_select_end_id:
                del multi_select_end_id[chat_id]
            client.remove_event_handler(selection_handler)
        await asyncio.sleep(300)
        try:
            client.remove_event_handler(selection_handler)
        except:
            pass

    @client.on(events.NewMessage(pattern=r'\.save$'))
    async def save_media(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if not event.is_reply:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ روی یه پیام حاوی عکس، ویدیو، گیف یا فایل ریپلای کن.")
            return
        replied = await event.get_reply_message()
        if not replied or not replied.media:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ پیام ریپلای شده حاوی مدیا نیست.")
            return
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"📥 در حال دانلود...")
        try:
            os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
            file_path = await replied.download_media(file=DOWNLOAD_FOLDER)
            if not file_path:
                await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ دانلود ناموفق بود.")
                return
            file_size = os.path.getsize(file_path) / 1024
            file_name = os.path.basename(file_path)
            meta_file = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")
            meta = {}
            if os.path.exists(meta_file):
                try:
                    with open(meta_file, "r") as f:
                        meta = json.load(f)
                except:
                    pass
            meta[file_name] = datetime.now().isoformat()
            with open(meta_file, "w") as f:
                json.dump(meta, f, indent=4)
            PUBLIC_HOST = os.getenv("PUBLIC_HOST", "185.183.33.91")
            PORT = os.getenv("PORT", "8800")
            encoded_filename = quote(file_name)
            download_link = f"http://{PUBLIC_HOST}:{PORT}/files/{encoded_filename}"
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"✅ دانلود شد!\n📁 {file_name}\n📦 {file_size:.1f} KB\n🔗 {download_link}\n\n⏳ لینک تا ۲۴ ساعت معتبر است.\n")
        except Exception as e:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"❌ خطا: {e}")

    @client.on(events.NewMessage(pattern=r'\.sl(?: (.+))?$'))
    async def save_list(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        filename_arg = event.pattern_match.group(1)
        if not os.path.exists(DOWNLOAD_FOLDER):
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "📭 پوشه downloads وجود ندارد.")
            return
        if filename_arg:
            filename_arg = filename_arg.strip()
            if filename_arg == "files_meta.json":
                await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ دسترسی به این فایل مجاز نیست.")
                return
            file_path = os.path.join(DOWNLOAD_FOLDER, filename_arg)
            if not os.path.exists(file_path) or not os.path.isfile(file_path):
                await client.send_message(int(os.getenv('OWNER_ID', 0)), f"❌ فایل `{filename_arg}` در پوشه downloads پیدا نشد.\nبرای دیدن لیست فایل‌ها از `.sl` استفاده کن.")
                return
            file_size = os.path.getsize(file_path) / 1024
            PUBLIC_HOST = os.getenv("PUBLIC_HOST", "185.183.33.91")
            PORT = os.getenv("PORT", "8800")
            encoded_filename = quote(filename_arg)
            download_link = f"http://{PUBLIC_HOST}:{PORT}/files/{encoded_filename}"
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"🔗 **لینک دانلود:**\n📁 {filename_arg}\n📦 {file_size:.1f} KB\n🔗 {download_link}\n\n⏳ لینک تا ۲۴ ساعت معتبر است.")
            return
        files = os.listdir(DOWNLOAD_FOLDER)
        files = [f for f in files if f != "files_meta.json" and os.path.isfile(os.path.join(DOWNLOAD_FOLDER, f))]
        if not files:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "📭 هیچ فایلی در پوشه downloads وجود ندارد.")
            return
        total_size = 0
        msg = f"📁 **لیست فایل‌های موجود در downloads**\n━━━━━━━━━━━━━━━━━━━━━\n"
        for i, file in enumerate(files, 1):
            file_path = os.path.join(DOWNLOAD_FOLDER, file)
            size = os.path.getsize(file_path) / 1024
            total_size += os.path.getsize(file_path)
            mtime = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime("%Y-%m-%d %H:%M")
            msg += f"{i}. `{file}`\n   📦 {size:.1f} KB | 🕒 {mtime}\n\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n📊 حجم کل: {format_size(total_size)}\n📌 برای دریافت لینک یک فایل: `.sl [نام فایل]`"
        await client.send_message(int(os.getenv('OWNER_ID', 0)), msg)

    @client.on(events.NewMessage(pattern=r'\.copy$'))
    async def copy_text(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        if not event.is_reply:
            await event.edit("❌ روی یه پیام ریپلای کن تا متنش رو کپی کنم.")
            return
        replied = await event.get_reply_message()
        if not replied.text:
            await event.edit("❌ پیام ریپلای شده حاوی متن نیست.")
            return
        await event.delete()
        await client.send_message('me', f"📋 **متن کپی‌شده:**\n\n{replied.text}")
        confirm_msg = await client.send_message(event.chat_id, "✅ متن به پیوی شما ارسال شد.")
        await asyncio.sleep(3)
        await confirm_msg.delete()

    @client.on(events.NewMessage(pattern=r'\.clear (.+)$'))
    async def clear_file(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        filename = event.pattern_match.group(1).strip()
        if filename.lower() == "all":
            if os.path.exists(DOWNLOAD_FOLDER):
                total_size = 0
                for f in os.listdir(DOWNLOAD_FOLDER):
                    f_path = os.path.join(DOWNLOAD_FOLDER, f)
                    if f != "files_meta.json" and os.path.isfile(f_path):
                        total_size += os.path.getsize(f_path)
                        os.remove(f_path)
                meta_file = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")
                if os.path.exists(meta_file):
                    os.remove(meta_file)
                await client.send_message(int(os.getenv('OWNER_ID', 0)), f"🧹 همه فایل‌ها پاک شدند.\n📦 فضای آزاد شده: {format_size(total_size)}")
            else:
                await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ پوشه downloads وجود ندارد.")
            return
        file_path = os.path.join(DOWNLOAD_FOLDER, filename)
        if not os.path.exists(file_path) or not os.path.isfile(file_path):
            await client.send_message(int(os.getenv('OWNER_ID', 0)), f"❌ فایل `{filename}` در پوشه downloads پیدا نشد.\nبرای دیدن لیست فایل‌ها از `.sl` استفاده کن.")
            return
        file_size = os.path.getsize(file_path) / 1024
        os.remove(file_path)
        meta_file = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")
        if os.path.exists(meta_file):
            try:
                with open(meta_file, "r") as f:
                    meta = json.load(f)
                if filename in meta:
                    del meta[filename]
                with open(meta_file, "w") as f:
                    json.dump(meta, f, indent=4)
            except:
                pass
        await client.send_message(int(os.getenv('OWNER_ID', 0)), f"🗑️ فایل `{filename}` حذف شد.\n📦 فضای آزاد شده: {file_size:.1f} KB")

    @client.on(events.NewMessage(pattern=r'\.clean$'))
    async def clean_downloads(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        await event.delete()
        if os.path.exists(DOWNLOAD_FOLDER):
            shutil.rmtree(DOWNLOAD_FOLDER)
            os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "🧹 پوشه downloads پاکسازی شد.")
        else:
            await client.send_message(int(os.getenv('OWNER_ID', 0)), "❌ پوشه downloads وجود ندارد.")
