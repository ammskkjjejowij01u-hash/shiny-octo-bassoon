import os
import re
import requests
from datetime import datetime
from telethon import events

# ========== تنظیمات ==========
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
OWNER_ID = int(os.getenv("OWNER_ID", 0))

AI_LOG_FILE = "ai_log.txt"

def log_ai(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with open(AI_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")
    print(f"[{timestamp}] {message}")

def get_groq_response(messages):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": GROQ_MODEL,
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 2048,
        "top_p": 0.9,
        "stream": False
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        if response.status_code != 200:
            return None, response.status_code, response.text
        result = response.json()
        return result["choices"][0]["message"]["content"], None, None
    except Exception as e:
        return None, 0, str(e)

def extract_text_from_url(url):
    """دریافت متن از لینک با استفاده از requests و BeautifulSoup"""
    try:
        from bs4 import BeautifulSoup
        response = requests.get(url, timeout=30, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # حذف تگ‌های غیرضروری
        for tag in soup(['script', 'style', 'nav', 'footer', 'header', 'aside']):
            tag.decompose()
        
        text = soup.get_text()
        # تمیز کردن متن
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        text = '\n'.join(lines)
        
        # محدود کردن به ۵۰۰۰ کاراکتر
        return text[:5000]
    except Exception as e:
        log_ai(f"❌ خطا در دریافت لینک: {e}")
        return None

def register_summarizer(client, db):
    print("✅ Summarizer loaded!")
    
    if not GROQ_API_KEY:
        log_ai("⚠️ GROQ_API_KEY تنظیم نشده! خلاصه‌سازی کار نمی‌کنه.")
        return

    @client.on(events.NewMessage(pattern=r'\.sum'))
    async def summarize_command(event):
        if not event.sender_id == OWNER_ID:
            return
        
        # ===== دریافت متن کامل بعد از دستور =====
        full_text = event.message.text
        parts = full_text.split(maxsplit=1)
        
        if len(parts) < 2:
            await event.reply(
                "📝 **دستور خلاصه‌سازی**\n\n"
                "`.sum [متن]` → خلاصه‌سازی خودکار (۵۰ کلمه)\n"
                "`.sum [تعداد] [متن]` → خلاصه با تعداد کلمه دلخواه\n"
                "`.sum [لینک]` → خلاصه محتوای لینک\n\n"
                "مثال‌ها:\n"
                "`.sum من یک متن طولانی هستم...`\n"
                "`.sum 100 من یک متن طولانی هستم...`\n"
                "`.sum https://example.com/article`"
            )
            return
        
        text_part = parts[1].strip()
        
        # ===== بررسی وجود عدد برای تعداد کلمه =====
        word_count = 50  # پیش‌فرض
        text = text_part
        
        # بررسی آیا اولش عدد هست
        import re
        match = re.match(r'^(\d+)\s+(.+)$', text_part)
        if match:
            word_count = int(match.group(1))
            text = match.group(2).strip()
        
        if not text:
            await event.reply("❌ متنی برای خلاصه‌سازی وارد نشده.")
            return
        
        # ===== تشخیص لینک =====
        is_url = text.startswith(('http://', 'https://'))
        
        thinking_msg = await event.reply("🔄 در حال خلاصه‌سازی...")
        
        try:
            final_text = text
            
            if is_url:
                await thinking_msg.edit("📥 در حال دریافت محتوای لینک...")
                fetched_text = extract_text_from_url(text)
                if fetched_text:
                    final_text = fetched_text
                else:
                    await thinking_msg.edit("❌ دریافت محتوای لینک ناموفق بود.")
                    return
            
            # محدود کردن متن ورودی (برای جلوگیری از مصرف بیش از حد)
            if len(final_text) > 10000:
                final_text = final_text[:10000]
            
            system_prompt = (
                f"تو یک خلاصه‌ساز حرفه‌ای هستی. متن زیر را خلاصه کن و نکات اصلی را در حدود {word_count} کلمه بنویس. "
                "فقط خلاصه رو برگردان، هیچ توضیح اضافه‌ای نده. اگر متن فارسی بود، خلاصه رو فارسی بنویس."
            )
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": final_text}
            ]
            
            answer, status_code, error_text = get_groq_response(messages)
            
            if not answer:
                await thinking_msg.edit(f"❌ خطا: {status_code}")
                return
            
            source = "لینک" if is_url else "متن"
            word_count_actual = len(answer.split())
            
            final_msg = (
                f"📝 **خلاصه ({source})**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"{answer}\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📊 تعداد کلمات: {word_count_actual} | هدف: {word_count}"
            )
            await thinking_msg.edit(final_msg)
            log_ai(f"✅ خلاصه‌سازی: {answer[:100]}...")
            
        except Exception as e:
            await thinking_msg.edit(f"❌ خطا: {str(e)}")
            log_ai(f"❌ خطا: {e}")
