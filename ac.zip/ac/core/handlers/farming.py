import os
import json
import asyncio
import re
from datetime import datetime, timedelta
from telethon import events
from telethon.tl.types import InputMediaDice

OWNER_ID = int(os.getenv("OWNER_ID", 0))
TARGET_BOT = os.getenv("TARGET_BOT", "MeowieeeQBot")
RESPONSE_TIMEOUT = 60

USER_DATA_FILE = "user_data.json"
MODULES_FILE = "farm_modules.json"
FARMING_LOG_FILE = "farming_log.txt"

MEOW_INTERVAL = 5 * 60 + 31
CASINO_INTERVAL = 5 * 60 + 33
FISH_INTERVAL = 50 * 60
PISHI_INTERVAL = 90 * 60 + 30
DELAY_BETWEEN_COMMANDS = 3
STEP_DELAY = 5
FISH_WAIT = 15
MAX_CASINO_BET = 2_500_000

def load_json(file_path, default=None):
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except:
            return default or {}
    return default or {}

def save_json(file_path, data):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=4)

def get_user_data():
    default = {"balance": 0, "target_chat_id": None, "last_meow": None, "last_casino": None, "last_fish": None, "last_pishi": None}
    data = load_json(USER_DATA_FILE, default)
    for key in default:
        if key not in data:
            data[key] = default[key]
    return data

def save_user_data(data):
    save_json(USER_DATA_FILE, data)

def get_modules():
    default = {"meow": True, "casino": True, "fish": True, "pishi": True}
    return load_json(MODULES_FILE, default)

def save_modules(data):
    save_json(MODULES_FILE, data)

def format_number(num):
    return f"{num:,}"

def safe_round(value):
    return int(value)

def log_farming(level, message, detail=""):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    emoji = {"INFO": "ℹ️", "SUCCESS": "✅", "WARNING": "⚠️", "ERROR": "❌", "DEBUG": "🔍", "ACTION": "🔄", "TIMER": "⏳", "MONEY": "💰", "CLICK": "🖱️"}.get(level, "📌")
    log_line = f"[{timestamp}] {emoji} [{level}] {message}" + (f" | {detail}" if detail else "")
    with open(FARMING_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(log_line + "\n")
    print(log_line)

class FarmingManager:
    def __init__(self, client, db):
        self.client = client
        self.db = db
        self.is_running = False
        self.owner_id = OWNER_ID
        self.bot_name = TARGET_BOT
        user_data = get_user_data()
        self.chat_id = user_data.get("target_chat_id")
        self.modules = get_modules()
        self.waiting_for_response = False
        self.last_response_msg = None
        self.last_command = None
        self.retry_count = 0
        self._register_handlers()
        log_farming("INFO", f"🚀 فارم میو راه‌اندازی شد! (گروه: {self.chat_id})")

    def _register_handlers(self):
        @self.client.on(events.NewMessage(from_users=self.bot_name))
        async def bot_new_message_handler(event):
            if not self.waiting_for_response:
                return
            if event.chat_id != self.chat_id:
                return
            await self._process_bot_response(event, "NEW")
        @self.client.on(events.MessageEdited(from_users=self.bot_name))
        async def bot_edited_message_handler(event):
            if not self.waiting_for_response:
                return
            if event.chat_id != self.chat_id:
                return
            await self._process_bot_response(event, "EDITED")

    async def _process_bot_response(self, event, msg_type):
        try:
            text = event.message.text or ""
            has_buttons = bool(event.message.buttons)
            log_farming("DEBUG", f"📩 [{msg_type}] پاسخ: {text[:80]}...")
            self.last_response_msg = event.message
            self.waiting_for_response = False
            if "صبر کنی" in text or "استراحت بده" in text:
                match = re.search(r'باید\s*([\d:]+)\s*صبر کنی', text)
                if not match:
                    match = re.search(r'باید\s*([\d:]+)\s*ثانیه\s*صبر کنی', text)
                if not match:
                    match = re.search(r'⏳\s*باید\s*([\d:]+)\s*صبر کنی', text)
                if match:
                    time_str = match.group(1)
                    if ':' in time_str:
                        parts = time_str.split(':')
                        if len(parts) == 2:
                            wait_seconds = int(parts[0]) * 60 + int(parts[1])
                        else:
                            wait_seconds = int(parts[0])
                    else:
                        wait_seconds = int(time_str)
                    wait_seconds += 1
                    log_farming("TIMER", f"⏳ کول‌داون: {wait_seconds} ثانیه")
                    await asyncio.sleep(wait_seconds)
                    if self.last_command:
                        log_farming("ACTION", f"🔄 تکرار دستور: {self.last_command}")
                        await self._send_command(self.last_command)
                    return
            if "میو پوینت هات" in text or "میو پوینت گرفتی" in text:
                match = re.search(r'میو پوینت هات\s*:\s*`?([\d,]+)`?', text)
                if not match:
                    match = re.search(r'`([\d,]+)`', text)
                if match:
                    balance_str = match.group(1).replace(',', '')
                    balance = int(balance_str)
                    user_data = get_user_data()
                    old = user_data.get("balance", 0)
                    user_data["balance"] = balance
                    save_user_data(user_data)
                    self.retry_count = 0
                    log_farming("MONEY", f"✅ مع: {format_number(old)} → {format_number(balance)}")
                    return
            if "مبلغ دریافتی" in text:
                match_entry = re.search(r'مبلغ ورودی\s*:\s*`?([\d,]+)`?', text)
                match_prize = re.search(r'مبلغ دریافتی\s*:\s*`?([\d,]+)`?', text)
                if match_entry and match_prize:
                    entry = int(match_entry.group(1).replace(',', ''))
                    prize = int(match_prize.group(1).replace(',', ''))
                    user_data = get_user_data()
                    new_balance = user_data.get("balance", 0) - entry + prize
                    user_data["balance"] = new_balance
                    save_user_data(user_data)
                    log_farming("MONEY", f"✅ کازینو: ورودی {format_number(entry)} | دریافتی {format_number(prize)} | سود {format_number(prize - entry)} | موجودی: {format_number(new_balance)}")
                    return
            if "برداشت کردید" in text and "میو پوینت" in text:
                match = re.search(r'([\d,]+)\s*🪙\s*برداشت کردید', text)
                if match:
                    amount = int(match.group(1).replace(',', ''))
                    user_data = get_user_data()
                    new_balance = user_data.get("balance", 0) + amount
                    user_data["balance"] = new_balance
                    save_user_data(user_data)
                    log_farming("MONEY", f"✅ پیشی: +{format_number(amount)} | موجودی: {format_number(new_balance)}")
                    return
            log_farming("WARNING", f"⚠️ نوع پیام نامشخص: {text[:50]}...")
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در پردازش پاسخ: {e}")
            import traceback
            log_farming("ERROR", traceback.format_exc())

    async def _send_command(self, text):
        if not self.chat_id:
            log_farming("ERROR", "❌ گروه هدف تنظیم نشده!")
            return
        try:
            self.last_command = text
            self.waiting_for_response = True
            self.last_response_msg = None
            await self.client.send_message(self.chat_id, text)
            log_farming("ACTION", f"📤 ارسال: {text}")
            for _ in range(RESPONSE_TIMEOUT):
                await asyncio.sleep(1)
                if not self.waiting_for_response:
                    break
            if self.waiting_for_response:
                log_farming("WARNING", f"⏰ پاسخ برای دستور '{text}' دریافت نشد!")
                self.waiting_for_response = False
                self.last_response_msg = None
            await asyncio.sleep(STEP_DELAY)
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در ارسال دستور: {e}")
            self.waiting_for_response = False

    async def _click_button(self, row, col):
        if not self.last_response_msg:
            log_farming("WARNING", "⚠️ پیام مرجع برای کلیک وجود ندارد!")
            return False
        try:
            if not self.last_response_msg.buttons:
                log_farming("WARNING", "⚠️ پیام مرجع دکمه ندارد!")
                return False
            button = self.last_response_msg.buttons[row][col]
            self.waiting_for_response = True
            self.last_response_msg = None
            await button.click()
            log_farming("CLICK", f"🖱️ کلیک روی ردیف {row}، ستون {col}")
            for _ in range(RESPONSE_TIMEOUT):
                await asyncio.sleep(1)
                if not self.waiting_for_response:
                    break
            if self.waiting_for_response:
                log_farming("WARNING", f"⏰ پاسخ برای کلیک ({row},{col}) دریافت نشد!")
                self.waiting_for_response = False
                self.last_response_msg = None
                return False
            await asyncio.sleep(STEP_DELAY)
            return True
        except IndexError:
            log_farming("ERROR", f"❌ دکمه در ردیف {row}، ستون {col} وجود ندارد!")
            return False
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در کلیک: {e}")
            return False

    async def _send_slot(self):
        if not self.last_response_msg:
            log_farming("WARNING", "⚠️ پیام مرجع برای اسلات وجود ندارد!")
            return False
        try:
            reply_to_id = self.last_response_msg.id
            self.waiting_for_response = True
            self.last_response_msg = None
            await self.client.send_file(self.chat_id, InputMediaDice("🎰"), reply_to=reply_to_id)
            log_farming("ACTION", f"🎰 ارسال اسلات")
            for _ in range(RESPONSE_TIMEOUT):
                await asyncio.sleep(1)
                if not self.waiting_for_response:
                    break
            if self.waiting_for_response:
                log_farming("WARNING", f"⏰ پاسخ برای اسلات دریافت نشد!")
                self.waiting_for_response = False
                self.last_response_msg = None
                return False
            await asyncio.sleep(STEP_DELAY)
            return True
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در ارسال اسلات: {e}")
            return False

    async def _send_amount(self, amount):
        if not self.last_response_msg:
            log_farming("WARNING", "⚠️ پیام مرجع برای ارسال مبلغ وجود ندارد!")
            return False
        try:
            reply_to_id = self.last_response_msg.id
            self.waiting_for_response = True
            self.last_response_msg = None
            await self.client.send_message(self.chat_id, str(amount), reply_to=reply_to_id)
            log_farming("MONEY", f"💰 مبلغ ارسال شد: {format_number(amount)}")
            for _ in range(RESPONSE_TIMEOUT):
                await asyncio.sleep(1)
                if not self.waiting_for_response:
                    break
            if self.waiting_for_response:
                log_farming("WARNING", f"⏰ پاسخ برای مبلغ دریافت نشد!")
                self.waiting_for_response = False
                self.last_response_msg = None
                return False
            await asyncio.sleep(STEP_DELAY + 1)
            return True
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در ارسال مبلغ: {e}")
            return False

    async def start(self):
        if self.is_running:
            log_farming("WARNING", "⚠️ فارم میو در حال اجراست!")
            return
        if not self.chat_id:
            log_farming("ERROR", "❌ گروه هدف تنظیم نشده! از `.farm setgroup` استفاده کن.")
            return
        self.is_running = True
        log_farming("SUCCESS", f"🚀 فارم میو شروع شد! (گروه: {self.chat_id})")
        await self.client.send_message(self.owner_id, f"🚀 **فارم میو شروع شد!**\nگروه: {self.chat_id}")
        while self.is_running:
            try:
                await self._run_cycle()
                await asyncio.sleep(5)
            except Exception as e:
                log_farming("ERROR", f"❌ خطا در چرخه: {e}")
                await asyncio.sleep(10)

    async def stop(self):
        self.is_running = False
        await self.client.send_message(self.owner_id, "🛑 **فارم میو متوقف شد.**")
        log_farming("INFO", "🛑 فارم میو متوقف شد!")

    async def _run_cycle(self):
        if not self.is_running:
            return
        self.modules = get_modules()
        user_data = get_user_data()
        now = datetime.now()

        if self.modules.get("meow", True):
            last_meow = user_data.get("last_meow")
            if not last_meow or (now - datetime.fromisoformat(last_meow)).total_seconds() >= MEOW_INTERVAL:
                log_farming("ACTION", "🐱 اجرای مع...")
                await self._send_command("مع")
                if self.last_response_msg:
                    user_data = get_user_data()
                user_data["last_meow"] = datetime.now().isoformat()
                save_user_data(user_data)
                await asyncio.sleep(DELAY_BETWEEN_COMMANDS)
            else:
                remaining = int(MEOW_INTERVAL - (now - datetime.fromisoformat(last_meow)).total_seconds())
                log_farming("TIMER", f"⏳ مع: {remaining} ثانیه تا下次")
        else:
            log_farming("INFO", "⏭️ ماژول مع غیرفعال است.")

        if self.modules.get("casino", True):
            last_casino = user_data.get("last_casino")
            if not last_casino or (now - datetime.fromisoformat(last_casino)).total_seconds() >= CASINO_INTERVAL:
                balance = user_data.get("balance", 0)
                if balance >= 1000:
                    log_farming("ACTION", "🎰 اجرای کازینو...")
                    await self._run_casino()
                    user_data = get_user_data()
                    user_data["last_casino"] = datetime.now().isoformat()
                    save_user_data(user_data)
                    await asyncio.sleep(DELAY_BETWEEN_COMMANDS)
                else:
                    log_farming("WARNING", f"⚠️ موجودی کافی نیست: {format_number(balance)}")
            else:
                remaining = int(CASINO_INTERVAL - (now - datetime.fromisoformat(last_casino)).total_seconds())
                log_farming("TIMER", f"⏳ کازینو: {remaining} ثانیه تا下次")
        else:
            log_farming("INFO", "⏭️ ماژول کازینو غیرفعال است.")

        if self.modules.get("fish", True):
            last_fish = user_data.get("last_fish")
            if not last_fish or (now - datetime.fromisoformat(last_fish)).total_seconds() >= FISH_INTERVAL:
                log_farming("ACTION", "🐟 اجرای ماهی...")
                await self._send_command("ماهی")
                user_data = get_user_data()
                user_data["last_fish"] = datetime.now().isoformat()
                save_user_data(user_data)
                await asyncio.sleep(DELAY_BETWEEN_COMMANDS)
            else:
                remaining = int(FISH_INTERVAL - (now - datetime.fromisoformat(last_fish)).total_seconds())
                log_farming("TIMER", f"⏳ ماهی: {remaining} ثانیه تا下次")
        else:
            log_farming("INFO", "⏭️ ماژول ماهی غیرفعال است.")

        if self.modules.get("pishi", True):
            last_pishi = user_data.get("last_pishi")
            if not last_pishi or (now - datetime.fromisoformat(last_pishi)).total_seconds() >= PISHI_INTERVAL:
                log_farming("ACTION", "🐈 اجرای پیشی...")
                await self._send_command("پیشی")
                user_data = get_user_data()
                user_data["last_pishi"] = datetime.now().isoformat()
                save_user_data(user_data)
                await asyncio.sleep(DELAY_BETWEEN_COMMANDS)
            else:
                remaining = int(PISHI_INTERVAL - (now - datetime.fromisoformat(last_pishi)).total_seconds())
                log_farming("TIMER", f"⏳ پیشی: {remaining} ثانیه تا下次")
        else:
            log_farming("INFO", "⏭️ ماژول پیشی غیرفعال است.")

    async def _run_casino(self):
        try:
            await self._send_command("کازینو")
            if not self.last_response_msg:
                log_farming("ERROR", "⚠️ پیام کازینو دریافت نشد!")
                return
            if not await self._click_button(0, 1):
                log_farming("WARNING", "⏭️ کلیک اول ناموفق")
                return
            await asyncio.sleep(STEP_DELAY + 1)
            if not await self._click_button(0, 0):
                log_farming("WARNING", "⏭️ کلیک دوم ناموفق")
                return
            await asyncio.sleep(STEP_DELAY + 1)
            user_data = get_user_data()
            bet_amount = safe_round(user_data.get("balance", 0) / 3)
            if bet_amount < 1:
                bet_amount = 1
            elif bet_amount > MAX_CASINO_BET:
                bet_amount = MAX_CASINO_BET
            if not await self._send_amount(bet_amount):
                log_farming("WARNING", "⏭️ ارسال مبلغ ناموفق")
                return
            await asyncio.sleep(STEP_DELAY + 1)
            for i in range(3):
                if not await self._click_button(0, 0):
                    log_farming("WARNING", f"⏭️ کلیک {i+3} ناموفق")
                    break
                await asyncio.sleep(STEP_DELAY)
            await self._send_slot()
            log_farming("SUCCESS", "✅ کازینو انجام شد.")
        except Exception as e:
            log_farming("ERROR", f"❌ خطا در کازینو: {e}")

    async def set_target_chat(self, chat_id):
        user_data = get_user_data()
        user_data["target_chat_id"] = chat_id
        save_user_data(user_data)
        self.chat_id = chat_id
        log_farming("SUCCESS", f"✅ گروه هدف تنظیم شد: {chat_id}")
        return True

def register_farming(client, db):
    farming_manager = None

    @client.on(events.NewMessage(pattern=r'\.farm setgroup$'))
    async def farm_setgroup(event):
        if not event.sender_id == OWNER_ID:
            return
        nonlocal farming_manager
        if farming_manager is None:
            farming_manager = FarmingManager(client, db)
        chat_id = event.chat_id
        if chat_id >= 0:
            await event.edit("❌ این دستور باید در یک گروه اجرا شود.")
            return
        success = await farming_manager.set_target_chat(chat_id)
        if success:
            await event.edit(f"✅ گروه هدف تنظیم شد!\nآیدی گروه: `{chat_id}`")
            await client.send_message(OWNER_ID, f"✅ **گروه هدف تنظیم شد!**\nآیدی: `{chat_id}`")
        else:
            await event.edit("❌ خطا در تنظیم گروه هدف.")

    @client.on(events.NewMessage(pattern=r'\.farm start$'))
    async def farm_start(event):
        if not event.sender_id == OWNER_ID:
            return
        nonlocal farming_manager
        if farming_manager is None:
            farming_manager = FarmingManager(client, db)
        if not farming_manager.chat_id:
            await event.edit("❌ ابتدا گروه هدف را با `.farm setgroup` تنظیم کنید.")
            return
        await event.edit("🚀 **فارم میو شروع شد!**")
        await farming_manager.start()

    @client.on(events.NewMessage(pattern=r'\.farm stop$'))
    async def farm_stop(event):
        if not event.sender_id == OWNER_ID:
            return
        nonlocal farming_manager
        if farming_manager:
            await farming_manager.stop()
            await event.edit("🛑 **فارم میو متوقف شد.**")
        else:
            await event.edit("❌ فارم میو در حال اجرا نیست.")

    @client.on(events.NewMessage(pattern=r'\.farm status$'))
    async def farm_status(event):
        if not event.sender_id == OWNER_ID:
            return
        user_data = get_user_data()
        modules = get_modules()
        msg = f"📊 **وضعیت فارم میو**\n━━━━━━━━━━━━━━━━━━━━━\n📌 گروه هدف: {user_data.get('target_chat_id', 'تنظیم نشده')}\n💰 موجودی: {format_number(user_data.get('balance', 0))}\n━━━━━━━━━━━━━━━━━━━━━\n📋 **وضعیت ماژول‌ها:**\n  🐱 مع: {'✅ فعال' if modules.get('meow', True) else '❌ غیرفعال'}\n  🎰 کازینو: {'✅ فعال' if modules.get('casino', True) else '❌ غیرفعال'}\n  🐟 ماهی: {'✅ فعال' if modules.get('fish', True) else '❌ غیرفعال'}\n  🐈 پیشی: {'✅ فعال' if modules.get('pishi', True) else '❌ غیرفعال'}\n━━━━━━━━━━━━━━━━━━━━━\n💡 دستورات:\n  `.farm module <name> on/off`\n  `.farm module all on/off`"
        await event.edit(msg)

    @client.on(events.NewMessage(pattern=r'\.farm module (.+) (on|off)$'))
    async def farm_module(event):
        if not event.sender_id == OWNER_ID:
            return
        name = event.pattern_match.group(1).strip().lower()
        state = event.pattern_match.group(2).lower() == "on"
        modules = get_modules()
        if name == "all":
            for key in modules:
                modules[key] = state
            save_modules(modules)
            await event.edit(f"✅ همه ماژول‌ها {'فعال' if state else 'غیرفعال'} شدند.")
            return
        if name not in modules:
            await event.edit(f"❌ ماژول '{name}' وجود ندارد.\nماژول‌ها: meow, casino, fish, pishi")
            return
        modules[name] = state
        save_modules(modules)
        await event.edit(f"✅ ماژول '{name}' {'فعال' if state else 'غیرفعال'} شد.")

    @client.on(events.NewMessage(pattern=r'\.farm module list$'))
    async def farm_module_list(event):
        if not event.sender_id == OWNER_ID:
            return
        modules = get_modules()
        msg = "📋 **لیست ماژول‌ها:**\n  🐱 مع: {'✅ فعال' if modules.get('meow', True) else '❌ غیرفعال'}\n  🎰 کازینو: {'✅ فعال' if modules.get('casino', True) else '❌ غیرفعال'}\n  🐟 ماهی: {'✅ فعال' if modules.get('fish', True) else '❌ غیرفعال'}\n  🐈 پیشی: {'✅ فعال' if modules.get('pishi', True) else '❌ غیرفعال'}"
        await event.edit(msg)
