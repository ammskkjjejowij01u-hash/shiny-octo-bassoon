import os
import asyncio
import time
import logging
from telethon import events
from telethon.tl.types import InputMediaDice

logger = logging.getLogger(__name__)

async def casino_loop(client, event, target_numbers, max_attempts=30, show_in_chat=False, reply_to=None):
    chat_id = event.chat_id
    owner_id = int(event.sender_id)

    for attempt in range(1, max_attempts + 1):
        msg = None
        try:
            msg = await client.send_file(
                chat_id,
                InputMediaDice("🎰"),
                reply_to=reply_to
            )
            
            value = msg.media.value
            
            if value in target_numbers:
                if show_in_chat:
                    await client.send_message(chat_id, f"🎰 برد! مقدار {value} آمد!")
                await client.send_message(owner_id, f"🎰 برد! مقدار {value} (هدف: {target_numbers})")
                await client.send_message(owner_id, f"✅ بعد از {attempt} تلاش، {value} به دست آمد!")
                return True
            else:
                if msg:
                    try:
                        await msg.delete()
                        logger.debug(f"✅ اسلات ناموفق (عدد {value}) حذف شد.")
                    except Exception as e:
                        logger.warning(f"⚠️ خطا در حذف اسلات: {e}")
                await asyncio.sleep(1.5)
                
        except Exception as e:
            logger.error(f"❌ خطا در تلاش {attempt}: {e}")
            if msg:
                try:
                    await msg.delete()
                except Exception as e2:
                    logger.warning(f"⚠️ خطا در حذف اسلات (تلاش مجدد): {e2}")
            await asyncio.sleep(1.5)
    
    await client.send_message(
        owner_id,
        f"❌ بعد از {max_attempts} تلاش، هیچ‌کدام از اعداد به دست نیامد!\nاعداد: {target_numbers}"
    )
    return False

def register_casino(client, db):
    
    # ===================== .slot =====================
    @client.on(events.NewMessage(pattern=r'\.slot(?: (.+))?$'))
    async def slot_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        args = event.pattern_match.group(1)
        if not args:
            await event.edit(
                "🎰 **دستور اسلات**\n\n"
                "`.slot [عدد]` - شکار عدد خاص در اسلات (۱ تا ۶۴)\n"
                "`.slot [عدد1] [عدد2]` - شکار چند عدد\n"
                "`.slot [عدد] -show` - نمایش نتیجه در گروه\n\n"
                "مثال‌ها:\n"
                "`.slot 64` - شکار جکپات (برد بزرگ)\n"
                "`.slot 60 64` - شکار ۶۰ یا ۶۴\n"
                "`.slot 64 -show` - شکار جکپات با نمایش در گروه\n\n"
                "📌 اگر روی پیامی ریپلای کنید، اسلات روی همان پیام ریپلای می‌شود.\n"
                "📌 عدد ۶۴ به معنای جکپات (برد بزرگ) است."
            )
            return
        
        show_in_chat = False
        if args.endswith(' -show'):
            show_in_chat = True
            args = args[:-6].strip()
        
        numbers = []
        for p in args.split():
            if p.isdigit() and 1 <= int(p) <= 64:
                numbers.append(int(p))
        
        if not numbers:
            await event.edit("❌ عدد معتبر نیست. (۱ تا ۶۴)")
            return
        
        if len(numbers) > 10:
            await event.edit("⚠️ حداکثر 10 عدد مجاز است.")
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎯 شروع شکار اعداد {numbers} در اسلات..."
        )
        
        await casino_loop(client, event, numbers, show_in_chat=show_in_chat, reply_to=reply_to)

    # ===================== .ts (تست اسلات - بدون حذف) =====================
    @client.on(events.NewMessage(pattern=r'\.ts$'))
    async def test_slot(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        start = time.time()
        
        msg = await client.send_file(
            event.chat_id,
            InputMediaDice("🎰"),
            reply_to=reply_to
        )
        value = msg.media.value
        
        elapsed = int((time.time() - start) * 1000)
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎰 **تست اسلات**\n\n"
            f"📤 اسلات ارسال شد: 🎰\n"
            f"📥 مقدار: **{value}**\n"
            f"⏱️ زمان کل: {elapsed}ms\n"
            f"📌 پیام‌ها **حذف نشدند**."
        )
    
    # ===================== .tsd (تست اسلات با حذف) =====================
    @client.on(events.NewMessage(pattern=r'\.tsd$'))
    async def test_slot_delete(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        start = time.time()
        
        msg = await client.send_file(
            event.chat_id,
            InputMediaDice("🎰"),
            reply_to=reply_to
        )
        value = msg.media.value
        
        try:
            await msg.delete()
        except Exception as e:
            logger.warning(f"⚠️ خطا در حذف اسلات تست: {e}")
        
        elapsed = int((time.time() - start) * 1000)
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎰 **تست اسلات (با حذف)**\n\n"
            f"📤 اسلات ارسال شد: 🎰\n"
            f"📥 مقدار: **{value}**\n"
            f"⏱️ زمان کل: {elapsed}ms\n"
            f"🗑️ پیام‌ها **حذف شدند**."
        )
    
    # ===================== .sn (عدد اسلات از پیام موجود) =====================
    @client.on(events.NewMessage(pattern=r'\.sn$'))
    async def slot_number(event):
        """دریافت عدد اسلات از پیام موجود (ریپلای روی یک اسلات)"""
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        if not event.is_reply:
            await event.edit("❌ روی یک پیام اسلات ریپلای کن.")
            return
        
        replied = await event.get_reply_message()
        
        # چک کن که پیام ریپلای شده یک اسلات باشه
        if not replied.media or not hasattr(replied.media, 'value'):
            await event.edit("❌ این پیام یک اسلات نیست.")
            return
        
        value = replied.media.value
        
        await event.edit(f"🎰 **عدد اسلات**\n\n📥 مقدار: **{value}**")
