import os
import json
import asyncio
import re
from telethon import events

def register_admin(client, db):
    
    @client.on(events.NewMessage(pattern=r'\.on$'))
    async def bot_on(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
        except:
            settings = {"bot_enabled": False, "low_rarity_filter": True}
        settings['bot_enabled'] = True
        with open('settings.json', 'w') as f:
            json.dump(settings, f, indent=4)
        await event.edit("✅ Bot ON")
    
    @client.on(events.NewMessage(pattern=r'\.off$'))
    async def bot_off(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
        except:
            settings = {"bot_enabled": True, "low_rarity_filter": True}
        settings['bot_enabled'] = False
        with open('settings.json', 'w') as f:
            json.dump(settings, f, indent=4)
        await event.edit("❌ Bot OFF")
    
    @client.on(events.NewMessage(pattern=r'\.on lr$'))
    async def on_lr(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
        except:
            settings = {"bot_enabled": True, "low_rarity_filter": False}
        settings['low_rarity_filter'] = True
        with open('settings.json', 'w') as f:
            json.dump(settings, f, indent=4)
        await event.edit("✅ LR filter ON")
    
    @client.on(events.NewMessage(pattern=r'\.off lr$'))
    async def off_lr(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
        except:
            settings = {"bot_enabled": True, "low_rarity_filter": True}
        settings['low_rarity_filter'] = False
        with open('settings.json', 'w') as f:
            json.dump(settings, f, indent=4)
        await event.edit("❌ LR filter OFF")
    
    @client.on(events.NewMessage(pattern=r'\.dbinfo$'))
    async def db_info(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        total = len(db.data)
        rarity_count = {}
        for data in db.data.values():
            rarity = data.get('rarity', 'Unknown')
            rarity_count[rarity] = rarity_count.get(rarity, 0) + 1
        
        rarity_order = [
            "Common", "Uncommon", "Rare", "Legendary",
            "Mystical", "Divine", "CrossVerse", "Cataphract", "Supreme", "CNFT"
        ]
        
        msg = f"📊 **اطلاعات دیتابیس**\n━━━━━━━━━━━━━━━━━━━━━\n📦 تعداد کل: {total}\n━━━━━━━━━━━━━━━━━━━━━\n"
        if rarity_count:
            msg += f"\n📊 **پراکندگی راریتی:**\n"
            for rarity in rarity_order:
                if rarity in rarity_count:
                    count = rarity_count[rarity]
                    msg += f"  {rarity}: {count}\n"
        await event.edit(msg)
    
    # ===================== .help (دو قسمتی) =====================
    @client.on(events.NewMessage(pattern=r'\.help$'))
    async def help_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        help_part1 = """
📚 **راهنمای کامل یوزربات - بخش ۱ از ۲**

━━━━━━━━━━━━━━━━━━━━━
🔹 **دستورات اصلی (روشن/خاموش)**
━━━━━━━━━━━━━━━━━━━━━
`.on` - روشن کردن کل یوزربات
`.off` - خاموش کردن کل یوزربات
`.on lr` - فعال‌سازی فیلتر سطح پایین (کاراکترهای 🟠🟣🔵 رو نگیر)
`.off lr` - غیرفعال‌سازی فیلتر سطح پایین
`.dbinfo` - نمایش اطلاعات کامل دیتابیس
`.dbup [عدد]` - به‌روزرسانی دیتابیس
`.help` - نمایش همین راهنما

━━━━━━━━━━━━━━━━━━━━━
🔹 **دستورات اتوکچر (شکار خودکار)**
━━━━━━━━━━━━━━━━━━━━━
`.on ac` - فعال‌سازی اتوکچر در این گروه
`.off ac` - غیرفعال‌سازی اتوکچر در این گروه
`.on all` - فعال‌سازی اتوکچر در همه گروه‌ها
`.off all` - غیرفعال‌سازی اتوکچر در همه گروه‌ها
`.n` - تست تشخیص (بدون زمان)
`.nt` - تست تشخیص (با زمان)
`.ac stats` - نمایش آمار اتوکچر
`.ac list` - نمایش لیست کاراکترهای گرفته‌شده
`.ac delay [ms]` - تنظیم تأخیر
`.ac filter [rarity]` - فیلتر راریتی
`.ac log on/off` - لاگ‌گیری اتوکچر
`.ac reset` - ریست آمارها
`.ac analyze` - تحلیل گروه فعلی
`.ac boost on/off` - حالت سرعت بالا

━━━━━━━━━━━━━━━━━━━━━
🔹 **فیلتر ترکیبی (چند راریتی)**
━━━━━━━━━━━━━━━━━━━━━
`.ac filter add [rarity]` - اضافه کردن راریتی به فیلتر
`.ac filter remove [rarity]` - حذف راریتی از فیلتر
`.ac filter list` - نمایش فیلترهای فعلی
`.ac filter clear` - پاک کردن همه فیلترها

━━━━━━━━━━━━━━━━━━━━━
🔹 **جستجو و آمار**
━━━━━━━━━━━━━━━━━━━━━
`.search [name]` - جستجوی کاراکتر با اسم
`.search anime [name]` - جستجو بر اساس انیمه
`.search id [id]` - جستجو با شماره
`.search rarity [rarity]` - جستجو بر اساس راریتی
`.stats` - نمایش آمار کلی
`.report daily` - گزارش امروز
`.report weekly` - گزارش این هفته
`.report reset` - ریست گزارش‌ها

━━━━━━━━━━━━━━━━━━━━━
🔹 **انتخاب بازه و دانلود فایل**
━━━━━━━━━━━━━━━━━━━━━
`.cs` - شروع بازه (روی اولین پیام ریپلای کنید)
`.ce` - پایان بازه (روی آخرین پیام ریپلای کنید)
`.ss` - شروع بازه چندگانه (روی اولین فایل ریپلای کنید)
`.se` - پایان بازه چندگانه (روی آخرین فایل ریپلای کنید)
`.save` - دانلود عکس/ویدیو/گیف از پیام ریپلای شده
`.sl` - نمایش لیست فایل‌های دانلود شده
`.sl [filename]` - دریافت لینک دانلود فایل خاص
`.clear [filename]` - حذف فایل خاص
`.clear all` - پاک کردن همه فایل‌ها
`.clean` - پاکسازی کامل پوشه downloads
"""
        await event.edit(help_part1)
        await asyncio.sleep(0.5)
        
        help_part2 = """
📚 **راهنمای کامل یوزربات - بخش ۲ از ۲**

━━━━━━━━━━━━━━━━━━━━━
🔹 **تاس و اسلات (قماربازی)**
━━━━━━━━━━━━━━━━━━━━━
`.dice [عدد]` - شکار عدد خاص در تاس (۱ تا ۶)
`.td` - تست تاس (بدون حذف)
`.tdd` - تست تاس (با حذف)
`.tn` - نمایش عدد تاس
`.slot [عدد]` - شکار عدد خاص در اسلات (۱ تا ۶۴)
`.ts` - تست اسلات (بدون حذف)
`.tsd` - تست اسلات (با حذف)
`.sn` - نمایش عدد اسلات از پیام موجود

━━━━━━━━━━━━━━━━━━━━━
🔹 **دانلود از یوتیوب و شبکه‌های اجتماعی**
━━━━━━━━━━━━━━━━━━━━━
`.yt [لینک]` - دانلود از یوتیوب (با انتخاب کیفیت)
`.pt [لینک]` - دانلود از Pinterest
`.tt [لینک]` - دانلود از TikTok
`.ig [لینک]` - دانلود از Instagram
`.al [لینک]` - دانلود لینک مستقیم (هر فایلی)

━━━━━━━━━━━━━━━━━━━━━
🔹 **هوش مصنوعی (Gemini)**
━━━━━━━━━━━━━━━━━━━━━
`.ai [سوال]` - پرسیدن سوال از AI
`.ai status` - نمایش وضعیت
`.ai clear` - پاک کردن حافظه مکالمه

━━━━━━━━━━━━━━━━━━━━━
🔹 **فارم میو (Farming)**
━━━━━━━━━━━━━━━━━━━━━
`.farm setgroup` - تنظیم گروه فعلی به عنوان گروه هدف
`.farm start` - شروع فارم میو
`.farm stop` - توقف فارم میو
`.farm status` - نمایش وضعیت (موجودی و ماژول‌ها)
`.farm module <name> on/off` - فعال/غیرفعال کردن ماژول
`.farm module all on/off` - فعال/غیرفعال کردن همه ماژول‌ها
`.farm module list` - نمایش لیست ماژول‌ها

📌 **زمان‌بندی فارم میو:**
• مع: هر ۵ دقیقه و ۳۱ ثانیه
• کازینو: هر ۵ دقیقه و ۳۳ ثانیه
• ماهی: هر ۵۰ دقیقه
• پیشی: هر ۱ ساعت و نیم

━━━━━━━━━━━━━━━━━━━━━
🔹 **لاگ‌گیری**
━━━━━━━━━━━━━━━━━━━━━
`.log on/off` - فعال/غیرفعال کردن لاگ‌گیری
`.log view [تعداد]` - نمایش آخرین لاگ‌ها
`.log filter [کلمه]` - فیلتر کردن لاگ‌ها
`.log clear` - پاک کردن لاگ‌ها

━━━━━━━━━━━━━━━━━━━━━
💡 **نکات مهم:**
• اکثر دستورات باید در پیوی (Private) اجرا شوند.
• برای دستورات گروهی، حتماً در همان گروه اجرا کنید.
• برای `.save` و `.cs/.ce/.ss/.se` حتماً روی پیام مورد نظر ریپلای کنید.
• لینک‌های دانلود تا ۲۴ ساعت معتبر هستند.
"""
        await client.send_message(event.chat_id, help_part2)
    
    # ===================== .dbup =====================
    @client.on(events.NewMessage(pattern=r'\.dbup(?: (\d+))?$'))
    async def db_update(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        args = event.pattern_match.group(1)
        if args:
            end_at = int(args)
        else:
            end_at = 6500
        
        last_id = 0
        if db.data:
            try:
                ids = [int(k) for k in db.data.keys() if k.isdigit()]
                last_id = max(ids) if ids else 0
            except:
                last_id = 0
        
        start_from = last_id + 1
        
        if start_from > end_at:
            await event.edit(f"⚠️ آخرین شماره ({last_id}) از {end_at} بزرگتره. نیازی به آپدیت نیست.")
            return
        
        await event.edit(f"🔄 شروع آپدیت دیتابیس از {start_from} تا {end_at}...")
        
        response_received = asyncio.Event()
        last_response = None
        updated = 0
        failed = 0
        
        @client.on(events.NewMessage(from_users='Character_Catcher_Bot'))
        async def handler(e):
            nonlocal last_response, response_received
            if e.is_private and e.message.text and "Check out this character!" in e.message.text:
                last_response = e
                response_received.set()
            elif e.is_private and e.message.text and "Waifu not found." in e.message.text:
                last_response = e
                response_received.set()
        
        for i in range(start_from, end_at + 1):
            try:
                await client.send_message('@Character_Catcher_Bot', f'/check {i}')
                
                response_received.clear()
                try:
                    await asyncio.wait_for(response_received.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    failed += 1
                    continue
                
                event_msg = last_response
                text = event_msg.message.text
                
                if "Waifu not found." in text:
                    failed += 1
                    continue
                
                lines = text.split('\n')
                anime = None
                name = None
                rarity = None
                
                for line in lines:
                    line = line.strip()
                    if line.startswith('**') and line.endswith('**'):
                        content = line.strip('**').strip()
                        if content and not any(key in content for key in ['Check out', '𝙍𝘼𝙍𝙄𝙏𝙔', 'ᴄᴀᴜɢʜᴛ', 'ᴛᴏᴘ', 'http', 'OwO']):
                            anime = content
                            break
                
                for line in lines:
                    line = line.strip()
                    match = re.match(r'^\*\*(\d+):\s*(.+?)(?:\s*\[[^\]]*\])?\s*$', line)
                    if match:
                        name = match.group(2).strip()
                        name = re.sub(r'[\[\(][^\]\)]*[\]\)]', '', name).strip()
                        break
                
                for line in lines:
                    if '𝙍𝘼𝙍𝙄𝙏𝙔' in line:
                        match = re.search(r'𝙍𝘼𝙍𝙄𝙏𝙔:\s*(.+?)[\)\]]', line)
                        if match:
                            rarity = match.group(1).strip()
                        else:
                            rarity = line.split(':')[-1].strip().strip(')').strip(']').strip()
                        break
                
                if not name or not anime or not rarity:
                    failed += 1
                    continue
                
                file_unique_id = None
                if event_msg.message.photo:
                    file_unique_id = event_msg.message.photo.id
                elif event_msg.message.document:
                    file_unique_id = event_msg.message.document.id
                
                db.data[str(i)] = {
                    "id": i,
                    "name": name,
                    "anime": anime,
                    "rarity": rarity,
                    "file_unique_id": file_unique_id
                }
                
                updated += 1
                
                if updated % 5 == 0:
                    with open('data/full_database.json', 'w') as f:
                        json.dump(db.data, f, indent=4)
                    await event.edit(f"🔄 {updated} کاراکتر جدید اضافه شد...")
                
                await asyncio.sleep(1.2)
                
            except Exception as e:
                print(f"❌ خطا در {i}: {e}")
                failed += 1
                await asyncio.sleep(5)
                continue
        
        with open('data/full_database.json', 'w') as f:
            json.dump(db.data, f, indent=4)
        
        await event.edit(f"✅ آپدیت کامل شد!\n➕ {updated} کاراکتر جدید اضافه شد.\n❌ {failed} مورد ناموفق.\n📊 دیتابیس: {len(db.data)} کاراکتر")
