import os
import re
import asyncio
import yt_dlp
from urllib.parse import quote
from telethon import events

DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

YDL_OPTS_BASE = {
    'quiet': True, 'no_warnings': True, 'noplaylist': True, 'extract_flat': False,
    'ignoreerrors': True, 'no_check_certificate': True,
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'add_header': [('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
                   ('Accept-Language', 'en-us,en;q=0.5'),
                   ('Sec-Fetch-Mode', 'navigate')],
    'socket_timeout': 30, 'retries': 5, 'fragment_retries': 5,
}

def format_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes < 1024.0:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.1f} TB"

def is_youtube_link(text):
    patterns = [r'(https?://)?(www\.)?(youtube\.com|youtu\.be)/', r'(https?://)?(www\.)?(youtube\.com)/shorts/']
    return any(re.search(p, text) for p in patterns)

def get_file_size_mb(file_path):
    try:
        return os.path.getsize(file_path) / (1024 * 1024)
    except:
        return 0

def normalize_quality_input(text):
    text = text.strip().lower()
    if text.endswith('p'):
        text = text[:-1]
    return text

async def get_video_info(url):
    try:
        ydl_opts = {'quiet': True, 'no_warnings': True, 'extract_flat': False, 'noplaylist': True,
                    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                    'ignoreerrors': True, 'no_check_certificate': True}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return None, "اطلاعات ویدیو دریافت نشد"
            title = info.get('title', 'Unknown')
            duration = info.get('duration', 0)
            formats = info.get('formats', [])
            quality_list = []
            seen_heights = set()
            for f in formats:
                height = f.get('height')
                if height and f.get('vcodec') != 'none':
                    if height not in seen_heights:
                        seen_heights.add(height)
                        size = f.get('filesize') or f.get('filesize_approx')
                        quality_list.append({'height': height, 'size': size, 'size_human': format_size(size) if size else 'نامشخص'})
            quality_list.sort(key=lambda x: x['height'])
            best_height = max(seen_heights) if seen_heights else 0
            best_size = None
            for f in formats:
                if f.get('height') == best_height and f.get('vcodec') != 'none':
                    best_size = f.get('filesize') or f.get('filesize_approx')
                    break
            if not best_size and info.get('filesize'):
                best_size = info.get('filesize')
            return {'title': title, 'duration': duration, 'quality_list': quality_list, 'best_height': best_height,
                    'best_size': best_size, 'best_size_human': format_size(best_size) if best_size else 'نامشخص',
                    'duration_min': duration // 60, 'duration_sec': duration % 60}, None
    except Exception as e:
        return None, f"خطا در دریافت اطلاعات: {str(e)}"

async def download_youtube(url, height):
    if height == -1:
        fmt = 'bestaudio/best'
        postprocessors = [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}]
        merge = False
        height_label = 'audio'
    else:
        fmt = f"bestvideo[height<={height}]+bestaudio/best[height<={height}]/best"
        postprocessors = []
        merge = True
        height_label = f'{height}p'
    ydl_opts = {**YDL_OPTS_BASE, 'format': fmt, 'merge_output_format': 'mp4' if merge else None,
                'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s.%(ext)s'), 'postprocessors': postprocessors}
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            file_path = ydl.prepare_filename(info)
            if not os.path.exists(file_path):
                base = os.path.splitext(file_path)[0]
                for ext in ['.mp4', '.mkv', '.webm', '.mp3', '.m4a']:
                    test_path = base + ext
                    if os.path.exists(test_path):
                        file_path = test_path
                        break
            return file_path, info.get('title', 'Unknown'), height_label
    except Exception as e:
        return None, str(e), None

async def wait_for_reply(client, user_id, reply_to_msg_id, timeout):
    future = asyncio.get_event_loop().create_future()
    @client.on(events.NewMessage(from_users=user_id))
    async def handler(event):
        if event.message.reply_to and event.message.reply_to.reply_to_msg_id == reply_to_msg_id:
            if not future.done():
                future.set_result(event.message)
                client.remove_event_handler(handler)
    try:
        return await asyncio.wait_for(future, timeout=timeout)
    except asyncio.TimeoutError:
        return None
    finally:
        try:
            client.remove_event_handler(handler)
        except:
            pass

def register_yt_downloader(client, db):
    @client.on(events.NewMessage(pattern=r'\.yt(?: (.+))?$'))
    async def yt_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        user_id = event.sender_id
        chat_id = event.chat_id
        args = event.pattern_match.group(1)
        if not args:
            await event.edit("🎬 **دستور دانلود یوتیوب**\n\n`.yt [لینک]` - لینک ویدیو را بفرستید تا کیفیت‌های موجود نمایش داده شود.\n\nسپس روی پیام ریپلای کنید و کیفیت مورد نظر را بنویسید (مثلاً `1080`، `720`، `480`، `best` یا `audio`).\nپس از تأیید حجم، دانلود شروع می‌شود.")
            return
        url = args.strip()
        if not is_youtube_link(url):
            await event.edit("❌ لینک وارد شده معتبر نیست. فقط لینک یوتیوب پشتیبانی می‌شود.")
            return
        await event.delete()
        main_msg = await client.send_message(chat_id, "🔄 در حال دریافت اطلاعات ویدیو...")
        info, err = await get_video_info(url)
        if not info:
            await main_msg.edit(f"❌ خطا در دریافت اطلاعات ویدیو: {err or 'نامشخص'}")
            return
        msg = f"🎬 **{info['title']}**\n⏱️ مدت: {info['duration_min']}:{info['duration_sec']:02d}\n\n📊 **کیفیت‌های موجود (از کم به زیاد):**\n"
        for q in info['quality_list']:
            msg += f"  • `{q['height']}p`  |  حجم: {q['size_human']}\n"
        msg += f"\n🔝 **بهترین کیفیت موجود: {info['best_height']}p**\n📦 حجم تقریبی بهترین کیفیت: {info['best_size_human']}\n\n✅ **روی این پیام ریپلای کنید و کیفیت مورد نظر را بنویسید.**\nمثال: `1080` یا `720` یا `480` یا `best` یا `audio`"
        await main_msg.edit(msg)
        reply = await wait_for_reply(client, user_id, main_msg.id, 120)
        if not reply:
            await main_msg.edit("⏰ زمان انتخاب کیفیت به پایان رسید. درخواست لغو شد.")
            return
        quality_input_raw = reply.text.strip().lower()
        await reply.delete()
        quality_input = normalize_quality_input(quality_input_raw)
        if quality_input == 'audio':
            target_height = -1
            quality_label = 'audio'
        elif quality_input == 'best':
            target_height = info['best_height']
            quality_label = f'{target_height}p'
        elif quality_input.isdigit():
            target_height = int(quality_input)
            quality_label = f'{target_height}p'
        else:
            await main_msg.edit("❌ کیفیت نامعتبر. گزینه‌های معتبر: `best`, `audio`, یا عددی مثل `1080`.")
            return
        selected_size = None
        for q in info['quality_list']:
            if q['height'] == target_height:
                selected_size = q['size']
                break
        if target_height == -1:
            selected_size = info.get('best_size', 0) // 8
            if selected_size < 1:
                selected_size = 20 * 1024 * 1024
        if not selected_size:
            await main_msg.edit("❌ کیفیت انتخاب شده در دسترس نیست. لطفاً یکی از کیفیت‌های لیست را انتخاب کنید.")
            return
        size_human = format_size(selected_size) if selected_size else 'نامشخص'
        await main_msg.edit(f"🎬 **{info['title']}**\n⏱️ مدت: {info['duration_min']}:{info['duration_sec']:02d}\n🎯 کیفیت انتخاب‌شده: {quality_label}\n📦 **حجم تقریبی: {size_human}**\n\n✅ **روی این پیام ریپلای کنید و یکی از گزینه‌های زیر را بنویسید:**\n• `لینک` - دریافت لینک دانلود در پیوی (معتبر ۲۴ ساعت)\n• `فایل` - دریافت خود فایل در همین چت")
        confirm_reply = await wait_for_reply(client, user_id, main_msg.id, 60)
        if not confirm_reply:
            await main_msg.edit("⏰ زمان تأیید به پایان رسید. دانلود لغو شد.")
            return
        choice = confirm_reply.text.strip().lower()
        await confirm_reply.delete()
        if choice not in ['لینک', 'فایل']:
            await main_msg.edit("❌ گزینه نامعتبر. لطفاً `لینک` یا `فایل` را وارد کنید.")
            return
        await main_msg.edit("📥 در حال دانلود... لطفاً صبر کنید...")
        file_path, result, actual_quality = await download_youtube(url, target_height)
        if not file_path:
            await main_msg.edit(f"❌ خطا در دانلود:\n{result}")
            return
        file_size_mb = get_file_size_mb(file_path)
        file_name = os.path.basename(file_path)
        if file_size_mb > 2000:
            await main_msg.edit(f"⚠️ حجم فایل ({file_size_mb:.1f}MB) از حد مجاز تلگرام (۲۰۰۰MB) بیشتر است.\n📁 نام: {file_name}\n💡 از کیفیت پایین‌تر استفاده کنید.")
            try:
                os.remove(file_path)
            except:
                pass
            return
        public_host = os.getenv("PUBLIC_HOST", "185.183.33.91")
        port = os.getenv("PORT", "8800")
        encoded_filename = quote(file_name)
        download_link = f"http://{public_host}:{port}/files/{encoded_filename}"
        if choice == 'لینک':
            await client.send_message(user_id, f"🔗 **لینک دانلود ویدیو:**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n🎯 کیفیت: {actual_quality}\n🔗 {download_link}\n\n⏳ لینک تا ۲۴ ساعت معتبر است.")
            await main_msg.edit(f"✅ لینک دانلود به پیوی شما ارسال شد.")
        else:
            await main_msg.edit(f"📤 در حال ارسال فایل...\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
            try:
                await client.send_file(chat_id, file_path, caption=f"🎬 **دانلود شد!**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n🎯 کیفیت: {actual_quality}", supports_streaming=True)
                await main_msg.edit(f"✅ دانلود و ارسال شد!\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n🎯 کیفیت: {actual_quality}")
                try:
                    os.remove(file_path)
                except:
                    pass
            except Exception as e:
                await main_msg.edit(f"❌ خطا در ارسال فایل:\n{e}")
