import os
import asyncio
import time
import logging
from telethon import events
from telethon.tl.types import InputMediaDice

logger = logging.getLogger(__name__)

async def dice_loop(client, event, target_numbers, max_attempts=20, show_in_chat=False, reply_to=None):
    chat_id = event.chat_id
    owner_id = int(event.sender_id)

    for attempt in range(1, max_attempts + 1):
        msg = None
        try:
            msg = await client.send_file(
                chat_id,
                InputMediaDice("🎲"),
                reply_to=reply_to
            )
            
            value = msg.media.value
            
            if value in target_numbers:
                if show_in_chat:
                    await client.send_message(chat_id, f"🎲 برد! عدد {value} آمد!")
                await client.send_message(owner_id, f"🎲 برد! عدد {value} (هدف: {target_numbers})")
                await client.send_message(owner_id, f"✅ بعد از {attempt} تلاش، {value} به دست آمد!")
                return True
            else:
                # حذف پیام تاس (اگه ناموفق بود)
                if msg:
                    try:
                        await msg.delete()
                        logger.debug(f"✅ تاس ناموفق (عدد {value}) حذف شد.")
                    except Exception as e:
                        logger.warning(f"⚠️ خطا در حذف تاس: {e}")
                await asyncio.sleep(1.2)
                
        except Exception as e:
            logger.error(f"❌ خطا در تلاش {attempt}: {e}")
            if msg:
                try:
                    await msg.delete()
                except Exception as e2:
                    logger.warning(f"⚠️ خطا در حذف تاس (تلاش مجدد): {e2}")
            await asyncio.sleep(1.2)
    
    await client.send_message(
        owner_id,
        f"❌ بعد از {max_attempts} تلاش، هیچ‌کدام از اعداد به دست نیامد!\nاعداد: {target_numbers}"
    )
    return False

def register_dice(client, db):
    
    # ===================== .dice =====================
    @client.on(events.NewMessage(pattern=r'\.dice(?: (.+))?$'))
    async def dice_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        args = event.pattern_match.group(1)
        if not args:
            await event.edit(
                "🎲 **دستور تاس**\n\n"
                "`.dice [عدد]` - شکار عدد خاص\n"
                "`.dice [عدد1] [عدد2]` - شکار چند عدد\n"
                "`.dice [عدد] -show` - نمایش نتیجه در گروه\n\n"
                "مثال‌ها:\n"
                "`.dice 6` - شکار ۶\n"
                "`.dice 5 6` - شکار ۵ یا ۶\n"
                "`.dice 6 -show` - شکار ۶ با نمایش در گروه\n\n"
                "📌 اگر روی پیامی ریپلای کنید، تاس روی همان پیام ریپلای می‌شود."
            )
            return
        
        show_in_chat = False
        if args.endswith(' -show'):
            show_in_chat = True
            args = args[:-6].strip()
        
        numbers = []
        for p in args.split():
            if p.isdigit() and 1 <= int(p) <= 6:
                numbers.append(int(p))
        
        if not numbers:
            await event.edit("❌ عدد معتبر نیست. (۱ تا ۶)")
            return
        
        if len(numbers) > 10:
            await event.edit("⚠️ حداکثر 10 عدد مجاز است.")
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎯 شروع شکار اعداد {numbers} در تاس..."
        )
        
        await dice_loop(client, event, numbers, show_in_chat=show_in_chat, reply_to=reply_to)
    
    # ===================== .td (تست تاس) =====================
    @client.on(events.NewMessage(pattern=r'\.td$'))
    async def test_dice(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        start = time.time()
        
        msg = await client.send_file(
            event.chat_id,
            InputMediaDice("🎲"),
            reply_to=reply_to
        )
        value = msg.media.value
        
        elapsed = int((time.time() - start) * 1000)
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎲 **تست تاس**\n\n"
            f"📤 تاس ارسال شد: 🎲\n"
            f"📥 عدد: **{value}**\n"
            f"⏱️ زمان کل: {elapsed}ms\n"
            f"📌 پیام‌ها **حذف نشدند**."
        )
    
    # ===================== .tdd (تست تاس با حذف) =====================
    @client.on(events.NewMessage(pattern=r'\.tdd$'))
    async def test_dice_delete(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        start = time.time()
        
        msg = await client.send_file(
            event.chat_id,
            InputMediaDice("🎲"),
            reply_to=reply_to
        )
        value = msg.media.value
        
        try:
            await msg.delete()
            logger.debug("✅ تاس تست با حذف، پاک شد.")
        except Exception as e:
            logger.warning(f"⚠️ خطا در حذف تاس تست: {e}")
        
        elapsed = int((time.time() - start) * 1000)
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎲 **تست تاس (با حذف)**\n\n"
            f"📤 تاس ارسال شد: 🎲\n"
            f"📥 عدد: **{value}**\n"
            f"⏱️ زمان کل: {elapsed}ms\n"
            f"🗑️ پیام‌ها **حذف شدند**."
        )
    
    # ===================== .tn (عدد تاس) =====================
    @client.on(events.NewMessage(pattern=r'\.tn$'))
    async def dice_number(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        reply_to = None
        if event.is_reply:
            replied = await event.get_reply_message()
            reply_to = replied.id
        
        await event.delete()
        start = time.time()
        
        msg = await client.send_file(
            event.chat_id,
            InputMediaDice("🎲"),
            reply_to=reply_to
        )
        value = msg.media.value
        
        elapsed = int((time.time() - start) * 1000)
        
        await client.send_message(
            int(os.getenv('OWNER_ID', 0)),
            f"🎲 **عدد تاس**\n\n"
            f"📤 تاس ارسال شد: 🎲\n"
            f"📥 عدد: **{value}**\n"
            f"⏱️ زمان کل: {elapsed}ms"
        )
