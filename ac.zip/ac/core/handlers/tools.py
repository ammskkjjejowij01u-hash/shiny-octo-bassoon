import os
import math
import re
import requests
import json
from datetime import datetime, timedelta
from telethon import events
from pint import UnitRegistry

OWNER_ID = int(os.getenv("OWNER_ID", 0))
CACHE_FILE = "currency_cache.json"
CACHE_DURATION = 120  # ۲ دقیقه

ureg = UnitRegistry()

def log_tool(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with open("tools_log.txt", 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")
    print(f"[{timestamp}] {message}")

# ============================================================
# ✅ ماشین حساب
# ============================================================
def safe_calc(expression):
    allowed_funcs = {
        'sin': math.sin, 'cos': math.cos, 'tan': math.tan,
        'asin': math.asin, 'acos': math.acos, 'atan': math.atan,
        'sinh': math.sinh, 'cosh': math.cosh, 'tanh': math.tanh,
        'sqrt': math.sqrt, 'log': math.log, 'log10': math.log10,
        'log2': math.log2, 'exp': math.exp, 'pow': math.pow,
        'pi': math.pi, 'e': math.e, 'tau': math.tau,
        'radians': math.radians, 'degrees': math.degrees,
        'abs': abs, 'round': round, 'int': int, 'float': float
    }
    
    expression = expression.replace('^', '**')
    expression = re.sub(r'[^0-9a-zA-Z+\-*/().,sqrtlognp i e]', '', expression)
    
    try:
        result = eval(expression, {"__builtins__": {}}, allowed_funcs)
        return result
    except Exception as e:
        return f"❌ خطا: {str(e)}"

# ============================================================
# ✅ دریافت نرخ ارز (API واقعی برای ایران)
# ============================================================
def get_currency_rate(from_currency, to_currency):
    """دریافت نرخ لحظه‌ای ارز از APIهای واقعی"""
    
    # ===== ۱. چک کردن کش =====
    cache = load_cache()
    key = f"{from_currency}_{to_currency}"
    if key in cache:
        cache_time = datetime.fromisoformat(cache[key]['time'])
        if datetime.now() - cache_time < timedelta(seconds=CACHE_DURATION):
            log_tool(f"📦 استفاده از کش: {key} = {cache[key]['rate']}")
            return cache[key]['rate']
    
    # ===== ۲. API اصلی: priceto.day (مخصوص ایران) =====
    # این API نرخ آزاد دلار رو میده
    try:
        # دریافت نرخ لحظه‌ای
        url = "https://api.priceto.day/v1/latest/irr/usd"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            # ساختار پاسخ: {"irr": {"usd": 0.0000075}}
            irr_to_usd = data.get('irr', {}).get('usd')
            if irr_to_usd and irr_to_usd > 0:
                # ۱ دلار = ۱ / irr_to_usd ریال
                rate = 1 / irr_to_usd
                save_cache('USD', 'IRR', rate)
                log_tool(f"✅ نرخ از PriceDB: 1 USD = {rate:,.0f} IRR")
                return rate
    except Exception as e:
        log_tool(f"⚠️ خطا در PriceDB: {e}")
    
    # ===== ۳. API پشتیبان: TGJU (سایت سکه) =====
    try:
        url = "https://www.tgju.org/profile/price_dollar_rl/data"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            # نرخ دلار از TGJU
            if 'price' in data:
                rate = float(data['price'])
                save_cache('USD', 'IRR', rate)
                log_tool(f"✅ نرخ از TGJU: 1 USD = {rate:,.0f} IRR")
                return rate
    except Exception as e:
        log_tool(f"⚠️ خطا در TGJU: {e}")
    
    # ===== ۴. API پشتیبان دوم: Navasan =====
    try:
        url = "https://api.navasan.tech/latest/?api_key=free&item=dollar"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            if 'dollar' in data and 'value' in data['dollar']:
                rate = float(data['dollar']['value'])
                save_cache('USD', 'IRR', rate)
                log_tool(f"✅ نرخ از Navasan: 1 USD = {rate:,.0f} IRR")
                return rate
    except Exception as e:
        log_tool(f"⚠️ خطا در Navasan: {e}")
    
    # ===== ۵. اگه همه APIها جواب ندادن =====
    log_tool("❌ همه APIها شکست خوردند!")
    return None

# ============================================================
# ✅ کش
# ============================================================
def load_cache():
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_cache(from_curr, to_curr, rate):
    try:
        cache = load_cache()
        key = f"{from_curr}_{to_curr}"
        cache[key] = {
            'rate': rate,
            'time': datetime.now().isoformat()
        }
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache, f, indent=2)
    except:
        pass

# ============================================================
# ✅ تبدیل واحد
# ============================================================
def convert_unit(value, from_unit, to_unit):
    
    # ===== ۱. دما =====
    temp_units = {'c': 'C', 'f': 'F', 'k': 'K', 'celsius': 'C', 'fahrenheit': 'F', 'kelvin': 'K'}
    from_lower = from_unit.lower()
    to_lower = to_unit.lower()
    
    if from_lower in temp_units and to_lower in temp_units:
        from_temp = temp_units[from_lower]
        to_temp = temp_units[to_lower]
        
        if from_temp == 'C':
            if to_temp == 'F':
                return (value * 9/5) + 32, 'F'
            elif to_temp == 'K':
                return value + 273.15, 'K'
        elif from_temp == 'F':
            if to_temp == 'C':
                return (value - 32) * 5/9, 'C'
            elif to_temp == 'K':
                return (value - 32) * 5/9 + 273.15, 'K'
        elif from_temp == 'K':
            if to_temp == 'C':
                return value - 273.15, 'C'
            elif to_temp == 'F':
                return (value - 273.15) * 9/5 + 32, 'F'
        
        return None, "دمای نامعتبر"
    
    # ===== ۲. ارز =====
    currency_map = {
        'usd': 'USD', 'eur': 'EUR', 'gbp': 'GBP', 'irr': 'IRR',
        'rial': 'IRR', 'toman': 'IRR', 'dollar': 'USD', 'euro': 'EUR', 'pound': 'GBP'
    }
    
    from_curr = currency_map.get(from_lower, from_unit.upper())
    to_curr = currency_map.get(to_lower, to_unit.upper())
    
    # اگه هر دو ارز باشن
    if from_curr in ['USD', 'EUR', 'GBP', 'IRR'] and to_curr in ['USD', 'EUR', 'GBP', 'IRR']:
        if from_curr == to_curr:
            return value, to_curr
        
        rate = get_currency_rate(from_curr, to_curr)
        
        if rate:
            result = value * rate
            # اگه خروجی IRR باشه، به تومان هم نشون بده
            if to_curr == 'IRR':
                toman = result / 10
                return result, f"IRR ({toman:,.0f} Toman)"
            return result, to_curr
        
        return None, "خطا در دریافت نرخ ارز"
    
    # ===== ۳. واحدهای معمولی (با pint) =====
    try:
        fix_map = {
            'kg': 'kilogram',
            'km': 'kilometer',
            'lb': 'pound',
            'mile': 'mile',
            'cm': 'centimeter',
            'mm': 'millimeter',
            'g': 'gram',
            'mg': 'milligram',
            'l': 'liter',
            'ml': 'milliliter',
            'gal': 'gallon',
            'm': 'meter',
            'ft': 'foot',
            'in': 'inch',
            'yard': 'yard',
        }
        
        from_fixed = fix_map.get(from_unit.lower(), from_unit)
        to_fixed = fix_map.get(to_unit.lower(), to_unit)
        
        result = (value * ureg(from_fixed)).to(to_fixed)
        return result.magnitude, result.units
    except Exception as e:
        return None, str(e)

# ============================================================
# ✅ ثبت دستورات
# ============================================================
def register_tools(client, db):
    
    @client.on(events.NewMessage(pattern=r'\.calc (.+)$'))
    async def calc_command(event):
        if not event.sender_id == OWNER_ID:
            return
        expression = event.pattern_match.group(1).strip()
        if not expression:
            await event.reply("❌ عبارتی وارد نشده.\nمثال: `.calc 2+2`")
            return
        result = safe_calc(expression)
        if isinstance(result, str) and result.startswith("❌"):
            await event.reply(result)
        else:
            if isinstance(result, float):
                if result.is_integer():
                    result = int(result)
                else:
                    result = round(result, 10)
            await event.reply(f"🧮 **نتیجه:**\n`{expression}` = **{result}**")
            log_tool(f"🧮 calc: {expression} = {result}")

    @client.on(events.NewMessage(pattern=r'\.convert (.+)$'))
    async def convert_command(event):
        if not event.sender_id == OWNER_ID:
            return
        full = event.pattern_match.group(1).strip()
        match = re.match(r'^(\d+\.?\d*)\s+(\w+)\s+(?:to|->)\s+(\w+)$', full)
        if not match:
            await event.reply(
                "❌ فرمت نامعتبر.\n"
                "مثال‌ها:\n"
                "`.convert 10 kg to lb`\n"
                "`.convert 100 USD to IRR`\n"
                "`.convert 5 km to mile`\n"
                "`.convert 30 C to F`"
            )
            return
        value = float(match.group(1))
        from_unit = match.group(2).strip()
        to_unit = match.group(3).strip()
        result, error = convert_unit(value, from_unit, to_unit)
        if result is None:
            await event.reply(f"❌ خطا: {error}")
            log_tool(f"❌ convert error: {error}")
            return
        if isinstance(result, float):
            if result.is_integer():
                result = int(result)
            else:
                result = round(result, 6)
        await event.reply(
            f"📐 **تبدیل واحد:**\n"
            f"{value} {from_unit} = **{result} {to_unit}**"
        )
        log_tool(f"📐 convert: {value} {from_unit} -> {result} {to_unit}")

    @client.on(events.NewMessage(pattern=r'\.tools help$'))
    async def tools_help(event):
        if not event.sender_id == OWNER_ID:
            return
        help_text = """
🧮 **دستورات ابزارها**

**ماشین حساب:**
`.calc [عبارت]` → محاسبه عبارت ریاضی

**تبدیل واحد:**
`.convert [مقدار] [واحد مبدأ] to [واحد مقصد]`

**پشتیبانی کامل از:**
• وزن: kg, g, lb, oz, ton
• طول: km, m, cm, mm, mile, yard, ft, in
• دما: C, F, K (با محاسبه دقیق)
• ارز: USD, EUR, GBP, IRR, Toman (با نرخ لحظه‌ای از APIهای ایرانی)
• حجم: L, ml, gal, pint
• و بسیاری دیگر...
"""
        await event.reply(help_text)
