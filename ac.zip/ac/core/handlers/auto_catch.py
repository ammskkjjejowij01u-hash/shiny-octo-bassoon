import os
import json
import asyncio
import time
import hashlib
import io
import re
from telethon import events
from collections import defaultdict
from datetime import datetime, timedelta

AC_SETTINGS_FILE = "ac_settings.json"
AC_LOG_FILE = "ac_log.txt"
ac_stats = {
    "total_caught": 0,
    "total_missed": 0,
    "total_attempts": 0,
    "last_caught": None,
    "caught_list": [],
    "rarity_count": defaultdict(int)
}
ac_delay = 0.02
ac_filter = None
ac_log_enabled = True

# ===================== ضریب سرعت =====================
speed_boost = False
boost_delay = 0.005

# ===================== تنظیمات پیشرفته =====================
ADV_SETTINGS_FILE = "adv_settings.json"
ADV_STATS = {
    "daily": {},
    "weekly": {},
    "total": {
        "caught": 0,
        "missed": 0,
        "attempts": 0,
        "rarity_count": defaultdict(int)
    }
}

def get_first_word(name):
    """گرفتن اولین کلمه از اسم کاراکتر"""
    if not name:
        return ""
    clean_name = name.replace('**', '').strip()
    words = clean_name.split()
    return words[0] if words else clean_name

def load_ac_settings():
    global ac_delay, ac_filter, ac_log_enabled, speed_boost
    if os.path.exists(AC_SETTINGS_FILE):
        try:
            with open(AC_SETTINGS_FILE, 'r') as f:
                settings = json.load(f)
                ac_delay = settings.get("delay", 0.02)
                ac_filter = settings.get("filter", None)
                ac_log_enabled = settings.get("log_enabled", True)
                speed_boost = settings.get("speed_boost", False)
        except:
            pass

def save_ac_settings():
    try:
        with open(AC_SETTINGS_FILE, 'w') as f:
            json.dump({
                "delay": ac_delay,
                "filter": ac_filter,
                "log_enabled": ac_log_enabled,
                "speed_boost": speed_boost
            }, f, indent=4)
    except:
        pass

def load_adv_stats():
    global ADV_STATS
    if os.path.exists(ADV_SETTINGS_FILE):
        try:
            with open(ADV_SETTINGS_FILE, 'r') as f:
                data = json.load(f)
                if "stats" in data:
                    ADV_STATS = data["stats"]
        except:
            pass

def save_adv_stats():
    try:
        with open(ADV_SETTINGS_FILE, 'w') as f:
            json.dump({
                "stats": ADV_STATS
            }, f, indent=4)
    except:
        pass

def log_ac(message):
    if ac_log_enabled:
        with open(AC_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
        print(f"📝 [AC Log] {message}")

def update_advanced_stats(name, rarity, success=True):
    now = datetime.now()
    day_key = now.strftime('%Y-%m-%d')
    week_key = (now - timedelta(days=now.weekday())).strftime('%Y-%m-%d')
    
    if success:
        ADV_STATS["total"]["caught"] += 1
        if rarity:
            ADV_STATS["total"]["rarity_count"][rarity] += 1
        
        if day_key not in ADV_STATS["daily"]:
            ADV_STATS["daily"][day_key] = {"caught": 0, "missed": 0, "attempts": 0, "rarity_count": {}}
        ADV_STATS["daily"][day_key]["caught"] += 1
        if rarity and rarity not in ADV_STATS["daily"][day_key]["rarity_count"]:
            ADV_STATS["daily"][day_key]["rarity_count"][rarity] = 0
        if rarity:
            ADV_STATS["daily"][day_key]["rarity_count"][rarity] += 1
        
        if week_key not in ADV_STATS["weekly"]:
            ADV_STATS["weekly"][week_key] = {"caught": 0, "missed": 0, "attempts": 0, "rarity_count": {}}
        ADV_STATS["weekly"][week_key]["caught"] += 1
        if rarity and rarity not in ADV_STATS["weekly"][week_key]["rarity_count"]:
            ADV_STATS["weekly"][week_key]["rarity_count"][rarity] = 0
        if rarity:
            ADV_STATS["weekly"][week_key]["rarity_count"][rarity] += 1
    else:
        ADV_STATS["total"]["missed"] += 1
    
    ADV_STATS["total"]["attempts"] += 1
    save_adv_stats()

def register_auto_catch(client, db):
    
    load_ac_settings()
    load_adv_stats()
    
    group_status = {}
    STATUS_FILE = 'group_status.json'
    
    def load_group_status():
        nonlocal group_status
        if os.path.exists(STATUS_FILE):
            try:
                with open(STATUS_FILE, 'r') as f:
                    group_status = json.load(f)
            except:
                group_status = {}
        else:
            group_status = {}
    
    def save_group_status():
        try:
            with open(STATUS_FILE, 'w') as f:
                json.dump(group_status, f, indent=4)
        except:
            pass
    
    load_group_status()
    
    def is_target_bot(sender):
        if not sender or not sender.username:
            return False
        return sender.username == 'Character_Catcher_Bot'
    
    def is_new_character_message(text):
        if not text:
            return False
        fancy = "ᴀ ᴄʜᴀʀᴀᴄᴛᴇʀ ʜᴀs sᴘᴀᴡɴᴇᴅ ɪɴ ᴛʜᴇ ᴄʜᴀᴛ!"
        normal = "a character has spawned in the chat!"
        return fancy in text or normal in text.lower()
    
    def is_low_rarity(text):
        if not text:
            return False
        low_emoji = ['🟠', '🟣', '🔵']
        return any(emoji in text for emoji in low_emoji)
    
    def extract_rarity_from_text(text):
        if not text:
            return None
        rarity_map = {
            'Common': 'Common',
            'Uncommon': 'Uncommon',
            'Rare': 'Rare',
            'Legendary': 'Legendary',
            'Mystical': 'Mystical',
            'Divine': 'Divine',
            'CrossVerse': 'CrossVerse',
            'Cataphract': 'Cataphract',
            'Supreme': 'Supreme',
            'CNFT': 'CNFT'
        }
        for key in rarity_map:
            if key in text:
                return rarity_map[key]
        return None
    
    # ===================== .ac analyze =====================
    @client.on(events.NewMessage(pattern=r'\.ac analyze(?: (.+))?$'))
    async def ac_analyze(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        chat_input = event.pattern_match.group(1)
        if chat_input:
            try:
                if chat_input.startswith('-100'):
                    chat_id = int(chat_input)
                else:
                    chat_id = int(chat_input)
            except:
                await event.edit("❌ آیدی نامعتبر.")
                return
        else:
            chat_id = event.chat_id
        
        chat_id_str = str(chat_id)
        
        caught_in_chat = []
        for item in ac_stats["caught_list"]:
            if item.get("chat_id") == chat_id_str:
                caught_in_chat.append(item)
        
        total_attempts = ac_stats["total_attempts"]
        caught = len(caught_in_chat)
        missed = ac_stats["total_missed"]
        success_rate = (caught / total_attempts * 100) if total_attempts > 0 else 0
        
        try:
            chat_entity = await client.get_entity(chat_id)
            chat_name = chat_entity.title if hasattr(chat_entity, 'title') else str(chat_id)
        except:
            chat_name = str(chat_id)
        
        msg = f"📊 **تحلیل گروه: {chat_name}**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🎯 تلاش‌ها: {total_attempts}\n"
        msg += f"✅ گرفته شده: {caught}\n"
        msg += f"❌ از دست رفته: {missed}\n"
        msg += f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        
        rarity_in_chat = defaultdict(int)
        for item in caught_in_chat:
            rarity_in_chat[item.get("rarity", "Unknown")] += 1
        
        if rarity_in_chat:
            msg += f"\n📊 **پراکندگی راریتی در این گروه:**\n"
            for rarity, count in sorted(rarity_in_chat.items(), key=lambda x: -x[1]):
                msg += f"  {rarity}: {count}\n"
        
        if caught_in_chat:
            msg += f"\n🔹 **آخرین ۵ کاراکتر در این گروه:**\n"
            for item in caught_in_chat[-5:]:
                msg += f"  - {item['name']} ({item['rarity']}) - {item['time']}\n"
        else:
            msg += f"\n❌ هنوز هیچ کاراکتری در این گروه گرفته نشده."
        
        await event.edit(msg)
        log_ac(f"📊 تحلیل گروه {chat_name} - {caught} کاراکتر")
    
    # ===================== .ac boost =====================
    @client.on(events.NewMessage(pattern=r'\.ac boost(?: (on|off))?$'))
    async def ac_boost(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        global speed_boost, boost_delay, ac_delay
        
        args = event.pattern_match.group(1)
        if args == 'on':
            speed_boost = True
            boost_delay = 0.005
            ac_delay = boost_delay
            save_ac_settings()
            await event.edit("🚀 حالت سرعت بالا فعال شد! (تأخیر ۵ms)")
            log_ac("🚀 حالت سرعت بالا فعال شد")
        elif args == 'off':
            speed_boost = False
            ac_delay = 0.02
            save_ac_settings()
            await event.edit("✅ حالت سرعت بالا غیرفعال شد.")
            log_ac("✅ حالت سرعت بالا غیرفعال شد")
        else:
            status = "فعال" if speed_boost else "غیرفعال"
            await event.edit(f"🔰 وضعیت سرعت بالا: **{status}**\n⏱️ تأخیر فعلی: {ac_delay * 1000:.0f}ms")
    
    # ===================== .ac stats =====================
    @client.on(events.NewMessage(pattern=r'\.ac stats$'))
    async def ac_stats_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        total = ac_stats["total_attempts"]
        caught = ac_stats["total_caught"]
        missed = ac_stats["total_missed"]
        success_rate = (caught / total * 100) if total > 0 else 0
        
        msg = f"📊 **آمار اتوکچر**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🎯 تلاش‌ها: {total}\n"
        msg += f"✅ گرفته شده: {caught}\n"
        msg += f"❌ از دست رفته: {missed}\n"
        msg += f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        if ac_stats["last_caught"]:
            msg += f"🔹 آخرین: {ac_stats['last_caught']}\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        if ac_stats["rarity_count"]:
            msg += f"\n📊 **پراکندگی راریتی:**\n"
            for rarity, count in sorted(ac_stats["rarity_count"].items(), key=lambda x: -x[1]):
                msg += f"  {rarity}: {count}\n"
        
        await event.edit(msg)
    
    # ===================== .ac list =====================
    @client.on(events.NewMessage(pattern=r'\.ac list$'))
    async def ac_list_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        caught = ac_stats["caught_list"]
        if not caught:
            await event.edit("❌ هنوز هیچ کاراکتری گرفته نشده.")
            return
        
        msg = f"📋 **لیست کاراکترهای گرفته‌شده**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        for i, item in enumerate(caught[-20:], 1):
            chat_name = item.get("chat_name", "Unknown")
            msg += f"{i}. {item['name']} ({item['rarity']}) - {item['time']} [@{chat_name}]\n"
        
        if len(caught) > 20:
            msg += f"\n... و {len(caught) - 20} مورد دیگر"
        
        await event.edit(msg)
    
    # ===================== .ac delay =====================
    @client.on(events.NewMessage(pattern=r'\.ac delay(?: (\d+))?$'))
    async def ac_delay_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        args = event.pattern_match.group(1)
        if args:
            try:
                new_delay = int(args) / 1000
                global ac_delay
                if speed_boost:
                    await event.edit("⚠️ حالت سرعت بالا فعال است! برای تغییر تأخیر، اول `.ac boost off` بزن.")
                    return
                ac_delay = max(0.001, min(1.0, new_delay))
                save_ac_settings()
                await event.edit(f"✅ تأخیر تنظیم شد: {ac_delay * 1000:.0f}ms")
            except:
                await event.edit("❌ عدد نامعتبر.")
        else:
            await event.edit(f"⏱️ تأخیر فعلی: {ac_delay * 1000:.0f}ms")
    
    # ===================== .ac filter =====================
    @client.on(events.NewMessage(pattern=r'\.ac filter(?: (.+))?$'))
    async def ac_filter_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        args = event.pattern_match.group(1)
        if args:
            global ac_filter
            if args.lower() in ['none', 'off']:
                ac_filter = None
                await event.edit("✅ فیلتر راریتی غیرفعال شد.")
            else:
                valid_rarities = ['Common', 'Uncommon', 'Rare', 'Legendary', 'Mystical', 'Divine', 'CrossVerse', 'Cataphract', 'Supreme', 'CNFT']
                found = None
                for r in valid_rarities:
                    if r.lower() == args.lower():
                        found = r
                        break
                if found:
                    ac_filter = found
                    await event.edit(f"✅ فیلتر فعال شد: فقط {found}")
                else:
                    await event.edit(f"❌ راریتی نامعتبر.\nگزینه‌ها: {', '.join(valid_rarities)}")
            save_ac_settings()
        else:
            if ac_filter:
                await event.edit(f"🔰 فیلتر فعلی: {ac_filter}")
            else:
                await event.edit("🔰 فیلتر راریتی غیرفعال است.")
    
    # ===================== .ac log =====================
    @client.on(events.NewMessage(pattern=r'\.ac log(?: (on|off))?$'))
    async def ac_log_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        args = event.pattern_match.group(1)
        if args:
            global ac_log_enabled
            if args == 'on':
                ac_log_enabled = True
                await event.edit("✅ لاگ‌گیری اتوکچر فعال شد.")
            else:
                ac_log_enabled = False
                await event.edit("❌ لاگ‌گیری اتوکچر غیرفعال شد.")
            save_ac_settings()
        else:
            await event.edit(f"🔰 وضعیت لاگ: {'فعال' if ac_log_enabled else 'غیرفعال'}")
    
    # ===================== .ac reset =====================
    @client.on(events.NewMessage(pattern=r'\.ac reset$'))
    async def ac_reset(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        ac_stats["total_caught"] = 0
        ac_stats["total_missed"] = 0
        ac_stats["total_attempts"] = 0
        ac_stats["last_caught"] = None
        ac_stats["caught_list"] = []
        ac_stats["rarity_count"] = defaultdict(int)
        
        ADV_STATS["total"]["caught"] = 0
        ADV_STATS["total"]["missed"] = 0
        ADV_STATS["total"]["attempts"] = 0
        ADV_STATS["total"]["rarity_count"] = defaultdict(int)
        ADV_STATS["daily"] = {}
        ADV_STATS["weekly"] = {}
        save_adv_stats()
        
        await event.edit("🔄 تمام آمارها ریست شدند.")
    
    # ===================== .on ac =====================
    @client.on(events.NewMessage(pattern=r'\.on ac$'))
    async def on_ac(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        chat_id = str(event.chat_id)
        group_status[chat_id] = True
        save_group_status()
        await event.edit("✅ Auto-Catch در این گپ فعال شد.")
    
    # ===================== .off ac =====================
    @client.on(events.NewMessage(pattern=r'\.off ac$'))
    async def off_ac(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        chat_id = str(event.chat_id)
        group_status[chat_id] = False
        save_group_status()
        await event.edit("❌ Auto-Catch در این گپ غیرفعال شد.")
    
    # ===================== .on all =====================
    @client.on(events.NewMessage(pattern=r'\.on all$'))
    async def on_all(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        dialogs = await client.get_dialogs()
        count = 0
        for d in dialogs:
            if d.is_group or d.is_channel:
                group_status[str(d.id)] = True
                count += 1
        save_group_status()
        await event.edit(f"✅ Auto-Catch در {count} گروه فعال شد.")
    
    # ===================== .off all =====================
    @client.on(events.NewMessage(pattern=r'\.off all$'))
    async def off_all(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        group_status.clear()
        save_group_status()
        await event.edit("❌ Auto-Catch در همه گروه‌ها غیرفعال شد.")
    
    # ===================== .n (فقط دستور - بدون زمان) =====================
    @client.on(events.NewMessage(pattern=r'\.n$'))
    async def test_media_no_time(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        
        if not event.is_reply:
            await event.edit("❌ روی یه عکس ریپلای کن.")
            return
        
        replied = await event.get_reply_message()
        if not replied or not replied.media:
            await event.edit("❌ پیام ریپلای شده حاوی عکس نیست.")
            return
        
        sender = await replied.get_sender()
        if not is_target_bot(sender):
            await event.edit("❌ ربات هدف نیست.")
            return
        
        file_unique_id = None
        if replied.photo:
            file_unique_id = replied.photo.id
        elif replied.document:
            file_unique_id = replied.document.id
        
        local_result = None
        if file_unique_id:
            local_result = db.get_by_unique_id(file_unique_id)
        
        if local_result:
            cmd = f"/catch@{sender.username}"
            full_name = local_result.get('name', '').replace('**', '').strip()
            name = get_first_word(full_name)
            if name:
                await event.delete()
                await client.send_message(event.chat_id, f"{cmd} {name}")
                log_ac(f"📤 [.n] {full_name} -> {name}")
            return
        
        try:
            file_bytes = io.BytesIO()
            await replied.download_media(file=file_bytes, thumb=-1)
            data = file_bytes.getvalue()
            if not data:
                await event.edit("❌ دانلود نشد.")
                return
        except Exception as e:
            await event.edit(f"❌ خطا در دانلود: {e}")
            return
        
        local_result = db.get_by_hash(data)
        if local_result:
            cmd = f"/catch@{sender.username}"
            full_name = local_result.get('name', '').replace('**', '').strip()
            name = get_first_word(full_name)
            if name:
                await event.delete()
                await client.send_message(event.chat_id, f"{cmd} {name}")
                log_ac(f"📤 [.n] {full_name} -> {name}")
            return
        
        await event.edit("❌ کاراکتر در دیتابیس پیدا نشد.")
    
    # ===================== .nt (تشخیص با زمان) =====================
    @client.on(events.NewMessage(pattern=r'\.nt$'))
    async def test_media_with_time(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        start = time.time()
        
        if not event.is_reply:
            await event.edit("❌ روی یه عکس ریپلای کن.")
            return
        
        replied = await event.get_reply_message()
        if not replied or not replied.media:
            await event.edit("❌ پیام ریپلای شده حاوی عکس نیست.")
            return
        
        sender = await replied.get_sender()
        if not is_target_bot(sender):
            await event.edit("❌ ربات هدف نیست.")
            return
        
        file_unique_id = None
        if replied.photo:
            file_unique_id = replied.photo.id
        elif replied.document:
            file_unique_id = replied.document.id
        
        local_result = None
        if file_unique_id:
            local_result = db.get_by_unique_id(file_unique_id)
        
        if local_result:
            cmd = f"/catch@{sender.username}"
            full_name = local_result.get('name', '').replace('**', '').strip()
            name = get_first_word(full_name)
            char_id = local_result.get('id', 'N/A')
            rarity = local_result.get('rarity', 'Unknown')
            elapsed = int((time.time() - start) * 1000)
            if name:
                await event.edit(f"`{cmd} {name}`\n⚡ {elapsed}ms")
                log_ac(f"📊 [.nt] {full_name} ({rarity}) [ID: {char_id}] -> {name} ✅ {elapsed}ms")
            return
        
        try:
            file_bytes = io.BytesIO()
            await replied.download_media(file=file_bytes, thumb=-1)
            data = file_bytes.getvalue()
            if not data:
                await event.edit("❌ دانلود نشد.")
                return
        except Exception as e:
            await event.edit(f"❌ خطا در دانلود: {e}")
            return
        
        local_result = db.get_by_hash(data)
        if local_result:
            cmd = f"/catch@{sender.username}"
            full_name = local_result.get('name', '').replace('**', '').strip()
            name = get_first_word(full_name)
            char_id = local_result.get('id', 'N/A')
            rarity = local_result.get('rarity', 'Unknown')
            elapsed = int((time.time() - start) * 1000)
            if name:
                await event.edit(f"`{cmd} {name}`\n⚡ {elapsed}ms")
                log_ac(f"📊 [.nt] {full_name} ({rarity}) [ID: {char_id}] -> {name} ✅ {elapsed}ms")
            return
        
        await event.edit("❌ کاراکتر در دیتابیس پیدا نشد.")
    
    # ===================== هندلر اصلی اتوکچر =====================
    @client.on(events.NewMessage)
    async def auto_catch(event):
        # ========== خواندن وضعیت bot_enabled از settings.json ==========
        bot_enabled = True
        if os.path.exists('settings.json'):
            try:
                with open('settings.json', 'r') as f:
                    settings = json.load(f)
                    bot_enabled = settings.get('bot_enabled', True)
            except:
                pass
        
        if not bot_enabled:
            return
        # ==============================================================
        
        if not event.message.media:
            return
        sender = await event.get_sender()
        if not is_target_bot(sender):
            return
        chat_id = str(event.chat_id)
        if not group_status.get(chat_id, False):
            return
        if not is_new_character_message(event.message.text or ""):
            return
        
        if os.path.exists('settings.json'):
            try:
                with open('settings.json', 'r') as f:
                    settings = json.load(f)
                    if settings.get('low_rarity_filter', False) and is_low_rarity(event.message.text or ""):
                        log_ac(f"⏭️ رد شد (سطح پایین) در چت {chat_id}")
                        return
            except:
                pass
        
        if ac_filter:
            rarity_in_text = extract_rarity_from_text(event.message.text or "")
            if rarity_in_text and rarity_in_text != ac_filter:
                log_ac(f"⏭️ رد شد (فیلتر {ac_filter}) در چت {chat_id}")
                return
        
        ac_stats["total_attempts"] += 1
        
        file_unique_id = None
        if event.message.photo:
            file_unique_id = event.message.photo.id
        elif event.message.document:
            file_unique_id = event.message.document.id
        
        local_result = None
        if file_unique_id:
            local_result = db.get_by_unique_id(file_unique_id)
        
        if not local_result:
            try:
                file_bytes = io.BytesIO()
                await event.message.download_media(file=file_bytes, thumb=-1)
                data = file_bytes.getvalue()
                if data:
                    local_result = db.get_by_hash(data)
            except:
                pass
        
        if not local_result:
            ac_stats["total_missed"] += 1
            update_advanced_stats(None, None, success=False)
            log_ac(f"❌ تشخیص داده نشد در چت {chat_id}")
            return
        
        cmd = f"/catch@{sender.username}"
        full_name = local_result.get('name', '').replace('**', '').strip()
        name = get_first_word(full_name)
        char_id = local_result.get('id', 'N/A')
        rarity = local_result.get('rarity', 'Unknown')
        
        if not name:
            ac_stats["total_missed"] += 1
            update_advanced_stats(None, None, success=False)
            return
        
        try:
            chat_entity = await client.get_entity(int(chat_id))
            chat_name = chat_entity.title if hasattr(chat_entity, 'title') else str(chat_id)
        except:
            chat_name = str(chat_id)
        
        ac_stats["total_caught"] += 1
        ac_stats["last_caught"] = full_name
        ac_stats["caught_list"].append({
            "name": full_name,
            "rarity": rarity,
            "time": time.strftime("%H:%M:%S"),
            "chat_id": chat_id,
            "chat_name": chat_name[:20]
        })
        ac_stats["rarity_count"][rarity] += 1
        
        update_advanced_stats(full_name, rarity, success=True)
        
        await asyncio.sleep(ac_delay)
        try:
            await event.reply(f"{cmd} {name}")
            log_ac(f"🎯 {full_name} ({rarity}) -> {name} [ID: {char_id}]")
        except Exception as e:
            log_ac(f"❌ خطا در ارسال {name}: {e}")
            ac_stats["total_missed"] += 1
            ac_stats["total_caught"] -= 1
            ac_stats["rarity_count"][rarity] -= 1
            if ac_stats["rarity_count"][rarity] < 0:
                ac_stats["rarity_count"][rarity] = 0
