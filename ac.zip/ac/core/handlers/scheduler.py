import os
import json
import asyncio
import re
from datetime import datetime, timedelta
from telethon import events

# ========== تنظیمات ==========
OWNER_ID = int(os.getenv("OWNER_ID", 0))
SCHEDULE_FILE = "schedule_data.json"

# ========== دیتابیس ==========
def load_schedules():
    if os.path.exists(SCHEDULE_FILE):
        try:
            with open(SCHEDULE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"tasks": [], "next_id": 1}
    return {"tasks": [], "next_id": 1}

def save_schedules(data):
    with open(SCHEDULE_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def parse_interval(time_str):
    """تبدیل 5s, 5m, 5h به ثانیه"""
    match = re.match(r'^(\d+)(s|m|h)$', time_str.lower())
    if not match:
        return None
    num = int(match.group(1))
    unit = match.group(2)
    if unit == 's':
        return num
    elif unit == 'm':
        return num * 60
    elif unit == 'h':
        return num * 3600
    return None

def parse_fixed_time(time_str):
    """تبدیل 08:00 یا 08:00:00 به datetime"""
    # پشتیبانی از HH:MM و HH:MM:SS
    if not re.match(r'^\d{2}:\d{2}(:\d{2})?$', time_str):
        return None
    
    parts = time_str.split(':')
    hour = int(parts[0])
    minute = int(parts[1])
    second = int(parts[2]) if len(parts) > 2 else 0
    
    if hour > 23 or minute > 59 or second > 59:
        return None
    
    now = datetime.now()
    target = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return target

def format_time(seconds):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60
    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"

def register_scheduler(client, db):
    
    # ===== راهنما =====
    @client.on(events.NewMessage(pattern=r'\.sd help$'))
    async def sd_help(event):
        if not event.sender_id == OWNER_ID:
            return
        await event.reply(
            "⏰ **دستورات زمان‌بندی**\n\n"
            "**فرمت کلی:**\n"
            "`.sd add [نوع] [پیام] [زمان] [تعداد]`\n\n"
            "**نوع‌ها:**\n"
            "• `t` = تکرار (interval)\n"
            "• `z` = زمان مشخص (fixed)\n\n"
            "**زمان:**\n"
            "• تکرار: `5s` (۵ ثانیه), `5m` (۵ دقیقه), `2h` (۲ ساعت)\n"
            "• زمان مشخص: `08:00` (ساعت ۸), `14:30:00` (۱۴:۳۰)\n\n"
            "**تعداد اجرا:**\n"
            "• `0` = بینهایت\n"
            "• `5` = ۵ بار\n\n"
            "**مثال‌ها:**\n"
            "`.sd add t سلام 5m 0` → هر ۵ دقیقه «سلام»\n"
            "`.sd add z سلام 08:00 0` → هر روز ساعت ۸ «سلام»\n"
            "`.sd add t تست 30s 10` → هر ۳۰ ثانیه «تست»، ۱۰ بار\n\n"
            "**مدیریت:**\n"
            "`.sd list` → لیست زمان‌بندی‌ها\n"
            "`.sd remove [id]` → حذف\n"
            "`.sd toggle [id]` → فعال/غیرفعال"
        )

    # ===== دستور اصلی =====
    @client.on(events.NewMessage(pattern=r'\.sd add ([tz]) (.+) (\d+s|\d+m|\d+h|\d{2}:\d{2}(:\d{2})?) (\d+)$'))
    async def sd_add(event):
        if not event.sender_id == OWNER_ID:
            return
        
        # استخراج داده‌ها
        type_char = event.pattern_match.group(1)
        message = event.pattern_match.group(2).strip()
        time_str = event.pattern_match.group(3)
        max_runs = int(event.pattern_match.group(4))
        
        chat_id = event.chat_id
        user_id = event.sender_id
        
        # بررسی نوع و زمان
        if type_char == 't':
            # حالت تکرار
            seconds = parse_interval(time_str)
            if not seconds:
                await event.reply("❌ زمان نامعتبر. مثال: `5s`, `5m`, `2h`")
                return
            
            time_type = "interval"
            interval_seconds = seconds
            next_run = datetime.now().isoformat()
            time_display = f"هر {format_time(seconds)}"
            
        else:  # 'z'
            # حالت زمان مشخص
            target_time = parse_fixed_time(time_str)
            if not target_time:
                await event.reply("❌ زمان نامعتبر. مثال: `08:00` یا `14:30:00`")
                return
            
            time_type = "fixed"
            interval_seconds = None
            next_run = target_time.isoformat()
            time_display = time_str
        
        # ساخت تسک
        schedules = load_schedules()
        task = {
            "id": schedules["next_id"],
            "user_id": user_id,
            "chat_id": chat_id,
            "message": message,
            "time_raw": time_str,
            "time_type": time_type,
            "interval_seconds": interval_seconds,
            "max_runs": max_runs,
            "run_count": 0,
            "active": True,
            "created_at": datetime.now().isoformat(),
            "last_run": None,
            "next_run": next_run
        }
        
        schedules["tasks"].append(task)
        schedules["next_id"] += 1
        save_schedules(schedules)
        
        chat_type = "گروه" if chat_id < 0 else "پیوی"
        runs_display = "∞" if max_runs == 0 else max_runs
        
        await event.reply(
            f"✅ **زمان‌بندی ثبت شد!**\n\n"
            f"📝 پیام: `{message[:50]}...`\n"
            f"⏰ زمان: {time_display}\n"
            f"📆 تعداد اجرا: {runs_display}\n"
            f"📍 ارسال در: {chat_type}\n"
            f"🆔 شناسه: {task['id']}"
        )

    # ===== لیست =====
    @client.on(events.NewMessage(pattern=r'\.sd list$'))
    async def sd_list(event):
        if not event.sender_id == OWNER_ID:
            return
        
        schedules = load_schedules()
        tasks = schedules.get("tasks", [])
        
        if not tasks:
            await event.reply("📭 هیچ زمان‌بندی فعالی وجود ندارد.")
            return
        
        msg = "⏰ **لیست زمان‌بندی‌ها**\n━━━━━━━━━━━━━━━━━━━━━\n"
        for task in tasks:
            status = "✅ فعال" if task.get("active", True) else "❌ غیرفعال"
            
            if task.get("time_type") == "interval":
                interval = task.get("interval_seconds", 0)
                time_display = f"هر {format_time(interval)}"
            else:
                time_display = task.get("time_raw", "نامشخص")
            
            runs_left = task.get("max_runs", 0) - task.get("run_count", 0)
            runs_text = "∞" if task.get("max_runs", 0) == 0 else runs_left
            
            chat_type = "گروه" if task.get("chat_id", 0) < 0 else "پیوی"
            msg += (
                f"🆔 `{task['id']}` | {status}\n"
                f"   📝 {task['message'][:40]}...\n"
                f"   ⏰ {time_display}\n"
                f"   📆 {runs_text} بار باقی‌مانده\n"
                f"   📍 {chat_type}\n\n"
            )
        
        msg += "━━━━━━━━━━━━━━━━━━━━━\n"
        msg += "`.sd remove [id]` - حذف\n"
        msg += "`.sd toggle [id]` - فعال/غیرفعال"
        
        await event.reply(msg)

    # ===== حذف =====
    @client.on(events.NewMessage(pattern=r'\.sd remove (\d+)$'))
    async def sd_remove(event):
        if not event.sender_id == OWNER_ID:
            return
        
        task_id = int(event.pattern_match.group(1))
        schedules = load_schedules()
        tasks = schedules.get("tasks", [])
        
        for i, task in enumerate(tasks):
            if task["id"] == task_id:
                tasks.pop(i)
                save_schedules(schedules)
                await event.reply(f"🗑️ زمان‌بندی `{task_id}` حذف شد.")
                return
        
        await event.reply(f"❌ زمان‌بندی `{task_id}` پیدا نشد.")

    # ===== فعال/غیرفعال =====
    @client.on(events.NewMessage(pattern=r'\.sd toggle (\d+)$'))
    async def sd_toggle(event):
        if not event.sender_id == OWNER_ID:
            return
        
        task_id = int(event.pattern_match.group(1))
        schedules = load_schedules()
        tasks = schedules.get("tasks", [])
        
        for task in tasks:
            if task["id"] == task_id:
                task["active"] = not task.get("active", True)
                save_schedules(schedules)
                status = "فعال" if task["active"] else "غیرفعال"
                await event.reply(f"🔄 زمان‌بندی `{task_id}` {status} شد.")
                return
        
        await event.reply(f"❌ زمان‌بندی `{task_id}` پیدا نشد.")

    # ===== چکر زمان‌بندی =====
    async def scheduler_loop():
        while True:
            try:
                now = datetime.now()
                schedules = load_schedules()
                tasks = schedules.get("tasks", [])
                
                for task in tasks:
                    if not task.get("active", True):
                        continue
                    
                    max_runs = task.get("max_runs", 0)
                    run_count = task.get("run_count", 0)
                    if max_runs > 0 and run_count >= max_runs:
                        task["active"] = False
                        await client.send_message(
                            task["user_id"],
                            f"⏰ زمان‌بندی `{task['id']}` به تعداد اجرای تعیین‌شده رسید و غیرفعال شد."
                        )
                        continue
                    
                    next_run = datetime.fromisoformat(task["next_run"])
                    
                    if now >= next_run:
                        try:
                            chat_id = task.get("chat_id", task["user_id"])
                            await client.send_message(chat_id, f"⏰ **یادآوری زمان‌بندی‌شده**\n\n{task['message']}")
                            
                            task["run_count"] = task.get("run_count", 0) + 1
                            
                            if task.get("time_type") == "interval":
                                interval = task.get("interval_seconds", 0)
                                task["next_run"] = (now + timedelta(seconds=interval)).isoformat()
                            else:
                                time_str = task.get("time_raw", "00:00")
                                parts = time_str.split(':')
                                hour = int(parts[0])
                                minute = int(parts[1])
                                second = int(parts[2]) if len(parts) > 2 else 0
                                
                                next_date = now.replace(hour=hour, minute=minute, second=second, microsecond=0)
                                if next_date <= now:
                                    next_date += timedelta(days=1)
                                task["next_run"] = next_date.isoformat()
                            
                            task["last_run"] = now.isoformat()
                            
                        except Exception as e:
                            print(f"❌ خطا در اجرای زمان‌بندی {task['id']}: {e}")
                
                save_schedules(schedules)
                await asyncio.sleep(10)
                
            except Exception as e:
                print(f"❌ خطا در scheduler_loop: {e}")
                await asyncio.sleep(30)
    
    client.loop.create_task(scheduler_loop())
