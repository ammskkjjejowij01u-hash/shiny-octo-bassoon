import os
import json
import time
import re
from datetime import datetime, timedelta
from collections import defaultdict
from telethon import events

ADV_SETTINGS_FILE = "adv_settings.json"
ADV_LOG_FILE = "adv_log.txt"
LOW_RARITY = ['Common', 'Uncommon', 'Rare']
ADV_STATS = {
    "daily": {},
    "weekly": {},
    "total": {
        "caught": 0,
        "missed": 0,
        "attempts": 0,
        "rarity_count": defaultdict(int)
    }
}

def load_adv_settings():
    global ADV_STATS
    if os.path.exists(ADV_SETTINGS_FILE):
        try:
            with open(ADV_SETTINGS_FILE, 'r') as f:
                data = json.load(f)
                if "stats" in data:
                    ADV_STATS = data["stats"]
        except:
            pass

def save_adv_settings():
    try:
        with open(ADV_SETTINGS_FILE, 'w') as f:
            json.dump({
                "stats": ADV_STATS
            }, f, indent=4)
    except:
        pass

def log_adv(message):
    with open(ADV_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")
    print(f"📝 [ADV Log] {message}")

def register_advanced(client, db):
    
    load_adv_settings()
    
    adv_filter = []
    log_enabled = True
    log_filter = None
    
    # بارگذاری فیلتر از فایل
    if os.path.exists(ADV_SETTINGS_FILE):
        try:
            with open(ADV_SETTINGS_FILE, 'r') as f:
                data = json.load(f)
                if "filter" in data:
                    adv_filter = data["filter"]
        except:
            pass
    
    @client.on(events.NewMessage(pattern=r'\.search(?: (.+))?$'))
    async def search_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        query = event.pattern_match.group(1)
        if not query:
            await event.edit("❌ چیزی برای جستجو وارد نکردی.\n"
                "مثال: `.search Gojo`\n"
                "مثال: `.search anime Naruto`\n"
                "مثال: `.search id 123`")
            return
        
        results = []
        
        if query.startswith('id '):
            char_id = query[3:].strip()
            if char_id.isdigit():
                for cid, data in db.data.items():
                    if cid == char_id:
                        results.append((cid, data))
                        break
        elif query.startswith('anime '):
            anime_query = query[6:].strip().lower()
            for cid, data in db.data.items():
                if anime_query in data.get('anime', '').lower():
                    results.append((cid, data))
        elif query.startswith('rarity '):
            rarity_query = query[7:].strip().lower()
            for cid, data in db.data.items():
                if rarity_query in data.get('rarity', '').lower():
                    results.append((cid, data))
        else:
            name_query = query.lower()
            for cid, data in db.data.items():
                name = data.get('name', '').replace('**', '').lower()
                if name_query in name:
                    results.append((cid, data))
        
        if not results:
            await event.edit(f"❌ نتیجه‌ای برای '{query}' پیدا نشد.")
            log_adv(f"🔍 جستجوی '{query}' - بدون نتیجه")
            return
        
        msg = f"🔍 **نتایج جستجو: `{query}`**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"📊 تعداد: {len(results)}\n\n"
        
        for cid, data in results[:20]:
            name = data.get('name', 'Unknown').replace('**', '').strip()
            anime = data.get('anime', 'Unknown')
            rarity = data.get('rarity', 'Unknown')
            msg += f"🆔 `{cid}`: {name}\n"
            msg += f"   📺 {anime} | 🏷️ {rarity}\n\n"
        
        if len(results) > 20:
            msg += f"... و {len(results) - 20} مورد دیگر"
        
        await event.edit(msg)
        log_adv(f"🔍 جستجوی '{query}' - {len(results)} نتیجه")
    
    @client.on(events.NewMessage(pattern=r'\.ac filter add (.+)$'))
    async def ac_filter_add(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        rarity = event.pattern_match.group(1).strip()
        if rarity not in ['Common', 'Uncommon', 'Rare', 'Mystical', 'Legendary', 'Divine', 'Supreme', 'Immortal']:
            await event.edit(f"❌ راریتی نامعتبر: {rarity}")
            return
        
        if rarity in adv_filter:
            await event.edit(f"⚠️ {rarity} از قبل در فیلتر وجود داره.")
            return
        
        adv_filter.append(rarity)
        with open(ADV_SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
        settings['filter'] = adv_filter
        with open(ADV_SETTINGS_FILE, 'w') as f:
            json.dump(settings, f, indent=4)
        
        await event.edit(f"✅ {rarity} به فیلتر اضافه شد.\nفیلتر فعلی: {', '.join(adv_filter)}")
        log_adv(f"⚙️ فیلتر +{rarity}")
    
    @client.on(events.NewMessage(pattern=r'\.ac filter remove (.+)$'))
    async def ac_filter_remove(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        rarity = event.pattern_match.group(1).strip()
        if rarity not in adv_filter:
            await event.edit(f"⚠️ {rarity} در فیلتر وجود نداره.")
            return
        
        adv_filter.remove(rarity)
        with open(ADV_SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
        settings['filter'] = adv_filter
        with open(ADV_SETTINGS_FILE, 'w') as f:
            json.dump(settings, f, indent=4)
        
        await event.edit(f"❌ {rarity} از فیلتر حذف شد.\nفیلتر فعلی: {', '.join(adv_filter) if adv_filter else 'خالی'}")
        log_adv(f"⚙️ فیلتر -{rarity}")
    
    @client.on(events.NewMessage(pattern=r'\.ac filter list$'))
    async def ac_filter_list(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        if not adv_filter:
            await event.edit("🔰 فیلتر فعلی خالی است (همه راریتی‌ها گرفته میشن).")
        else:
            await event.edit(f"🔰 فیلتر فعلی:\n{', '.join(adv_filter)}")
    
    @client.on(events.NewMessage(pattern=r'\.ac filter clear$'))
    async def ac_filter_clear(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        adv_filter.clear()
        with open(ADV_SETTINGS_FILE, 'r') as f:
            settings = json.load(f)
        settings['filter'] = adv_filter
        with open(ADV_SETTINGS_FILE, 'w') as f:
            json.dump(settings, f, indent=4)
        
        await event.edit("🗑️ فیلتر پاک شد (همه راریتی‌ها گرفته میشن).")
        log_adv("🗑️ فیلتر پاک شد")
    
    @client.on(events.NewMessage(pattern=r'\.stats$'))
    async def stats_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        total = ADV_STATS["total"]["attempts"]
        caught = ADV_STATS["total"]["caught"]
        missed = ADV_STATS["total"]["missed"]
        success_rate = (caught / total * 100) if total > 0 else 0
        
        msg = f"📊 **آمار کلی**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🎯 تلاش‌ها: {total}\n"
        msg += f"✅ گرفته شده: {caught}\n"
        msg += f"❌ از دست رفته: {missed}\n"
        msg += f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        if ADV_STATS["total"]["rarity_count"]:
            msg += f"\n📊 **پراکندگی راریتی:**\n"
            total_caught = ADV_STATS["total"]["caught"]
            for rarity, count in sorted(ADV_STATS["total"]["rarity_count"].items(), key=lambda x: -x[1]):
                pct = (count / total_caught * 100) if total_caught > 0 else 0
                msg += f"  {rarity}: {count} ({pct:.1f}%)\n"
        
        await event.edit(msg)
        log_adv("📊 نمایش آمار کلی")
    
    @client.on(events.NewMessage(pattern=r'\.report (daily|weekly)$'))
    async def report_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        report_type = event.pattern_match.group(1)
        now = datetime.now()
        
        if report_type == 'daily':
            key = now.strftime('%Y-%m-%d')
            data = ADV_STATS["daily"].get(key, {})
            title = f"📊 گزارش روزانه ({key})"
        else:
            week_start = (now - timedelta(days=now.weekday())).strftime('%Y-%m-%d')
            week_end = now.strftime('%Y-%m-%d')
            data = ADV_STATS["weekly"].get(week_start, {})
            title = f"📊 گزارش هفتگی ({week_start} تا {week_end})"
        
        caught = data.get('caught', 0)
        missed = data.get('missed', 0)
        attempts = data.get('attempts', 0)
        rarity_count = data.get('rarity_count', {})
        success_rate = (caught / attempts * 100) if attempts > 0 else 0
        
        msg = f"{title}\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🎯 تلاش‌ها: {attempts}\n"
        msg += f"✅ گرفته شده: {caught}\n"
        msg += f"❌ از دست رفته: {missed}\n"
        msg += f"📈 نرخ موفقیت: {success_rate:.1f}%\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        if rarity_count:
            msg += f"\n📊 **پراکندگی راریتی:**\n"
            for rarity, count in sorted(rarity_count.items(), key=lambda x: -x[1]):
                msg += f"  {rarity}: {count}\n"
        
        await event.edit(msg)
        log_adv(f"📊 گزارش {report_type}")
    
    @client.on(events.NewMessage(pattern=r'\.report reset$'))
    async def report_reset(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        ADV_STATS["daily"] = {}
        ADV_STATS["weekly"] = {}
        save_adv_settings()
        await event.edit("🔄 گزارش‌ها ریست شدند.")
        log_adv("🔄 گزارش‌ها ریست شدند")
    
    @client.on(events.NewMessage(pattern=r'\.log (on|off)$'))
    async def log_on_off(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        global log_enabled
        state = event.pattern_match.group(1)
        log_enabled = (state == 'on')
        
        await event.edit(f"{'✅' if log_enabled else '❌'} لاگ‌گیری {'فعال' if log_enabled else 'غیرفعال'} شد.")
        log_adv(f"⚙️ لاگ‌گیری: {'فعال' if log_enabled else 'غیرفعال'}")
    
    @client.on(events.NewMessage(pattern=r'\.log filter (.+)$'))
    async def log_filter_command(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        global log_filter
        log_filter = event.pattern_match.group(1)
        await event.edit(f"✅ فیلتر لاگ تنظیم شد: `{log_filter}`")
        log_adv(f"⚙️ فیلتر لاگ: {log_filter}")
    
    @client.on(events.NewMessage(pattern=r'\.log view(?: (\d+))?$'))
    async def log_view(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        lines = event.pattern_match.group(1)
        lines = int(lines) if lines and lines.isdigit() else 20
        
        if not os.path.exists(ADV_LOG_FILE):
            await event.edit("❌ فایل لاگ وجود ندارد.")
            return
        
        with open(ADV_LOG_FILE, 'r', encoding='utf-8') as f:
            all_lines = f.readlines()
        
        log_lines = all_lines[-lines:] if all_lines else []
        
        if not log_lines:
            await event.edit("📭 لاگ خالی است.")
            return
        
        msg = f"📋 **آخرین {len(log_lines)} لاگ**\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━━\n"
        for line in log_lines:
            msg += line
        
        await event.edit(msg)
    
    @client.on(events.NewMessage(pattern=r'\.log clear$'))
    async def log_clear(event):
        if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
            return
        if os.path.exists(ADV_LOG_FILE):
            with open(ADV_LOG_FILE, 'w') as f:
                f.write("")
        await event.edit("🗑️ لاگ‌ها پاک شدند.")
        log_adv("🗑️ لاگ‌ها پاک شدند")
