import os
import io
import json
import tempfile
import asyncio
import requests
from datetime import datetime
from telethon import events
from pathlib import Path

# ========== تنظیمات ==========
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "")
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
OWNER_ID = int(os.getenv("OWNER_ID", 0))

AI_LOG_FILE = "ai_log.txt"
user_conversations = {}

# ========== لاگ ==========
def log_ai(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with open(AI_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")
    print(f"[{timestamp}] {message}")

# ========== توابع Groq ==========
def get_groq_response(messages):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": GROQ_MODEL,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 2048,
        "top_p": 0.9,
        "stream": False
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        if response.status_code != 200:
            return None, response.status_code, response.text
        result = response.json()
        return result["choices"][0]["message"]["content"], None, None
    except Exception as e:
        return None, 0, str(e)

def search_tavily(query, max_results=5):
    try:
        url = "https://api.tavily.com/search"
        headers = {"Content-Type": "application/json"}
        payload = {
            "api_key": TAVILY_API_KEY,
            "query": query,
            "search_depth": "basic",
            "max_results": max_results,
            "include_answer": True,
            "include_raw_content": False
        }
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        if response.status_code != 200:
            log_ai(f"❌ خطای Tavily: {response.status_code}")
            return None
        return response.json()
    except Exception as e:
        log_ai(f"❌ خطا در جستجو: {e}")
        return None

def format_search_results(search_result):
    if not search_result:
        return "نتیجه‌ای پیدا نشد."
    answer = search_result.get('answer', '')
    results = search_result.get('results', [])
    text = ""
    if answer:
        text += f"📌 **پاسخ مستقیم:**\n{answer}\n\n"
    if results:
        text += "🔍 **نتایج جستجو:**\n"
        for i, r in enumerate(results[:5], 1):
            title = r.get('title', 'بدون عنوان')
            content = r.get('content', 'بدون توضیح')[:400]
            text += f"{i}. **{title}**\n{content}\n\n"
    return text

# ============================================================
# ✅ تشخیص نیاز به جستجو (ترکیبی: AI + کلمات کلیدی حیاتی)
# ============================================================
def needs_search_ai(query):
    """تشخیص نیاز به جستجو با ترکیب AI و کلمات کلیدی حیاتی"""
    if not TAVILY_API_KEY:
        return False
    
    # ===== مرحله ۱: چک کردن کلمات کلیدی حیاتی (همیشه جستجو کن) =====
    critical_keywords = [
        "قیمت", "نرخ", "ارز", "دلار", "یورو", "طلا", "سکه", "بورس", "سهام",
        "امروز", "الان", "لحظه", "آخرین", "به‌روز", "تغییر", "افزایش", "کاهش",
        "هوا", "آب و هوا", "طقس", "وضعیت هوا", "پیش‌بینی",
        "اخبار", "خبر", "انتخابات", "نتایج", "جدید", "تازه"
    ]
    
    query_lower = query.lower()
    for keyword in critical_keywords:
        if keyword in query_lower:
            log_ai(f"🔍 تصمیم جستجو: YES (کلمه کلیدی: {keyword})")
            return True
    
    # ===== مرحله ۲: اگر کلمه کلیدی نداشت، از AI بپرس =====
    try:
        messages = [
            {"role": "system", "content": "تو یک دستیار هوشمند هستی. فقط با YES یا NO پاسخ بده. آیا این سوال نیاز به اطلاعات به‌روز و جستجوی اینترنتی دارد؟ سوالاتی که درباره قیمت، نرخ ارز، آب و هوا، اخبار لحظه‌ای یا هر چیزی که تغییر می‌کند هستند، نیاز به جستجو دارند. سوالات عمومی و دانش ثابت نیاز به جستجو ندارند."},
            {"role": "user", "content": query}
        ]
        
        answer, status_code, error_text = get_groq_response(messages)
        
        if answer and "YES" in answer.upper():
            log_ai(f"🔍 تصمیم جستجو: YES (با AI)")
            return True
        else:
            log_ai(f"🔍 تصمیم جستجو: NO (با AI)")
            return False
            
    except Exception as e:
        log_ai(f"❌ خطا در تشخیص نیاز به جستجو: {e}")
        return False

# ========== تبدیل صدا به متن (Groq Whisper) ==========
async def transcribe_voice(file_path):
    if not GROQ_API_KEY:
        log_ai("❌ GROQ_API_KEY تنظیم نشده!")
        return None
    url = "https://api.groq.com/openai/v1/audio/transcriptions"
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}"}
    try:
        with open(file_path, "rb") as f:
            files = {"file": f}
            data = {"model": "whisper-large-v3", "language": "fa"}
            response = requests.post(url, headers=headers, files=files, data=data, timeout=30)
        if response.status_code == 200:
            return response.json().get("text", "")
        log_ai(f"❌ خطای Whisper: {response.text}")
        return None
    except Exception as e:
        log_ai(f"❌ خطا در Whisper: {e}")
        return None

# ========== تبدیل متن به صدا (با ElevenLabs) ==========
async def text_to_speech_elevenlabs(text):
    if not ELEVENLABS_API_KEY:
        return await text_to_speech_edge(text)
    
    try:
        if not text or len(text.strip()) == 0:
            text = "متاسفانه پاسخی دریافت نشد."
        
        if len(text) > 1000:
            text = text[:1000] + "..."
        
        url = "https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM"
        headers = {
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "xi-api-key": ELEVENLABS_API_KEY
        }
        data = {
            "text": text,
            "model_id": "eleven_monolingual_v1",
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.75
            }
        }
        
        response = requests.post(url, json=data, headers=headers, timeout=30)
        
        if response.status_code == 200:
            output_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3").name
            with open(output_file, 'wb') as f:
                f.write(response.content)
            return output_file
        else:
            log_ai(f"❌ خطای ElevenLabs: {response.status_code}")
            return await text_to_speech_edge(text)
            
    except Exception as e:
        log_ai(f"❌ خطا در ElevenLabs: {e}")
        return await text_to_speech_edge(text)

async def text_to_speech_edge(text):
    try:
        import edge_tts
        if not text or len(text.strip()) == 0:
            text = "متاسفانه پاسخی دریافت نشد."
        
        voice = "fa-IR-DilaraNeural"
        output_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3").name
        
        if len(text) > 1000:
            text = text[:1000] + "..."
        
        await edge_tts.Communicate(text, voice).save(output_file)
        return output_file
    except ImportError:
        log_ai("⚠️ edge-tts نصب نیست! نصب: pip install edge-tts")
        return None
    except Exception as e:
        log_ai(f"❌ خطا در TTS: {e}")
        return None

async def text_to_speech(text):
    if ELEVENLABS_API_KEY:
        result = await text_to_speech_elevenlabs(text)
        if result:
            return result
    return await text_to_speech_edge(text)

# ========== هندلر اصلی ==========
def register_ai_handler(client, db):
    
    if not GROQ_API_KEY:
        log_ai("⚠️ GROQ_API_KEY تنظیم نشده!")
        return

    # ============================================================
    # دستور `.ai`
    # ============================================================
    @client.on(events.NewMessage(pattern=r'\.ai(?: (.+))?$'))
    async def ai_command(event):
        if not event.sender_id == OWNER_ID:
            return
        
        user_id = event.sender_id
        prompt = event.pattern_match.group(1)

        if not prompt:
            await event.reply(
                "🤖 **دستور هوش مصنوعی**\n\n"
                "`.ai [سوال]` - پرسیدن سوال\n"
                "`.ai clear` - پاک کردن حافظه\n"
                "`.ai status` - نمایش وضعیت\n\n"
                "🔊 `.aiv` - روی پیام صوتی ریپلای کن"
            )
            return

        if prompt.lower().strip() == 'status':
            history_count = len(user_conversations.get(user_id, []))
            msg = (
                f"🤖 **وضعیت AI**\n"
                f"━━━━━━━━━━━━━━━━━━━━━\n"
                f"📱 مدل: {GROQ_MODEL}\n"
                f"🌐 جستجو: {'فعال (AI + کلمات کلیدی)' if TAVILY_API_KEY else 'غیرفعال'}\n"
                f"🧠 حافظه: {history_count}/10\n"
                f"💰 هزینه: کاملاً رایگان\n"
                f"⚡ سرعت: بالا (Groq LPU)"
            )
            await event.reply(msg)
            return

        if prompt.lower().strip() == 'clear':
            if user_id in user_conversations:
                del user_conversations[user_id]
            await event.reply("🧹 حافظه مکالمه پاک شد.")
            return

        thinking_msg = await event.reply("🧠 در حال تحلیل سوال...")

        try:
            # ===== تشخیص نیاز به جستجو =====
            should_search = needs_search_ai(prompt)
            search_text = ""

            if should_search:
                await thinking_msg.edit("🔍 در حال جستجو...")
                search_result = search_tavily(prompt)
                if search_result:
                    search_text = format_search_results(search_result)
                else:
                    # اگر Tavily کار نکرد، DuckDuckGo جایگزین
                    try:
                        from duckduckgo_search import DDGS
                        with DDGS() as ddgs:
                            results = []
                            for r in ddgs.text(prompt, max_results=5):
                                results.append(r)
                            if results:
                                search_text = "🔍 **نتایج جستجو (DuckDuckGo):**\n"
                                for i, r in enumerate(results[:5], 1):
                                    search_text += f"{i}. **{r.get('title', 'بدون عنوان')}**\n{r.get('body', '')[:300]}\n\n"
                    except Exception as e:
                        log_ai(f"❌ خطا در DuckDuckGo: {e}")

            # ساخت پیام برای Groq
            history = user_conversations.get(user_id, [])
            system_prompt = "تو یک دستیار هوشمند و مفید هستی. به فارسی پاسخ بده."
            if search_text:
                system_prompt += " بر اساس اطلاعات جستجو شده، پاسخ بده. حتماً از اطلاعات جستجو استفاده کن و پاسخ دقیق بده."
            
            messages = [{"role": "system", "content": system_prompt}]
            for msg in history:
                messages.append(msg)
            
            if search_text:
                messages.append({"role": "user", "content": f"سوال: {prompt}\n\nاطلاعات جستجو:\n{search_text}"})
            else:
                messages.append({"role": "user", "content": prompt})

            await thinking_msg.edit("🧠 در حال تولید پاسخ...")

            answer, status_code, error_text = get_groq_response(messages)
            
            if not answer:
                await thinking_msg.edit(f"❌ خطا: {status_code} - {error_text[:100]}")
                return

            if user_id not in user_conversations:
                user_conversations[user_id] = []
            user_conversations[user_id].append({"role": "user", "content": prompt})
            user_conversations[user_id].append({"role": "assistant", "content": answer})
            if len(user_conversations[user_id]) > 10:
                user_conversations[user_id] = user_conversations[user_id][-10:]

            source = "جستجو + Groq" if search_text else "Groq"
            final_msg = f"🤖 **پاسخ ({source}):**\n\n{answer}"
            await thinking_msg.edit(final_msg)
            log_ai(f"✅ پاسخ: {answer[:100]}...")

        except Exception as e:
            await thinking_msg.edit(f"❌ خطا: {str(e)}")
            log_ai(f"❌ خطا: {e}")

    # ============================================================
    # دستور `.aiv` (دستیار صوتی)
    # ============================================================
    @client.on(events.NewMessage(pattern=r'\.aiv$'))
    async def voice_assistant(event):
        if not event.sender_id == OWNER_ID:
            return
        
        if not event.is_reply:
            await event.reply("❌ روی یک پیام صوتی ریپلای کن!")
            return
        
        replied = await event.get_reply_message()
        if not replied.voice and not replied.audio:
            await event.reply("❌ این پیام یک فایل صوتی نیست!")
            return
        
        thinking = await event.reply("🎤 در حال پردازش پیام صوتی...")
        
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".ogg") as tmp:
                await client.download_media(replied, tmp.name)
                file_path = tmp.name
            
            text = await transcribe_voice(file_path)
            os.unlink(file_path)
            
            if not text:
                await thinking.edit("❌ خطا در تشخیص صدا!")
                return
            
            # ===== تشخیص نیاز به جستجو =====
            should_search = needs_search_ai(text)
            search_text = ""

            if should_search:
                await thinking.edit("🔍 در حال جستجو...")
                search_result = search_tavily(text)
                if search_result:
                    search_text = format_search_results(search_result)
                else:
                    try:
                        from duckduckgo_search import DDGS
                        with DDGS() as ddgs:
                            results = []
                            for r in ddgs.text(text, max_results=5):
                                results.append(r)
                            if results:
                                search_text = "🔍 **نتایج جستجو (DuckDuckGo):**\n"
                                for i, r in enumerate(results[:5], 1):
                                    search_text += f"{i}. **{r.get('title', 'بدون عنوان')}**\n{r.get('body', '')[:300]}\n\n"
                    except Exception as e:
                        log_ai(f"❌ خطا در DuckDuckGo: {e}")

            system_prompt = "تو یک دستیار هوشمند و مفید هستی. به فارسی پاسخ بده. پاسخ را مختصر و مفید بده."
            if search_text:
                system_prompt += " بر اساس اطلاعات جستجو شده، پاسخ بده."
            
            messages = [{"role": "system", "content": system_prompt}]
            if search_text:
                messages.append({"role": "user", "content": f"سوال: {text}\n\nاطلاعات جستجو:\n{search_text}"})
            else:
                messages.append({"role": "user", "content": text})

            await thinking.edit("🧠 در حال تولید پاسخ...")

            answer, status_code, error_text = get_groq_response(messages)
            
            if not answer:
                await thinking.edit(f"❌ خطا در دریافت پاسخ: {status_code}")
                return

            await thinking.delete()
            
            voice_file = await text_to_speech(answer)
            
            if not voice_file:
                await event.reply(f"🤖 **پاسخ:**\n\n{answer}")
                return
            
            await client.send_file(
                event.chat_id,
                voice_file,
                voice_note=True,
                reply_to=event.id
            )
            os.unlink(voice_file)
            
            log_ai(f"✅ پاسخ صوتی: {answer[:100]}...")

        except Exception as e:
            await thinking.edit(f"❌ خطا: {str(e)}")
            log_ai(f"❌ خطا در .aiv: {e}")
