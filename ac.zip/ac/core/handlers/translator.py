import os
import requests
from datetime import datetime
from telethon import events

# ========== تنظیمات ==========
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
OWNER_ID = int(os.getenv("OWNER_ID", 0))

AI_LOG_FILE = "ai_log.txt"

def log_ai(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    with open(AI_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"[{timestamp}] {message}\n")
    print(f"[{timestamp}] {message}")

def get_groq_response(messages):
    """ارسال درخواست به Groq"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": GROQ_MODEL,
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 2048,
        "top_p": 0.9,
        "stream": False
    }
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        if response.status_code != 200:
            return None, response.status_code, response.text
        result = response.json()
        return result["choices"][0]["message"]["content"], None, None
    except Exception as e:
        return None, 0, str(e)

def register_translator(client, db):
    if not GROQ_API_KEY:
        log_ai("⚠️ GROQ_API_KEY تنظیم نشده! ترجمه کار نمی‌کنه.")
        return

    @client.on(events.NewMessage(pattern=r'\.tr(?:\s+(\w+))?\s+(.+)$'))
    async def translate_command(event):
        if not event.sender_id == OWNER_ID:
            return
        
        target_lang = event.pattern_match.group(1)  # زبان مقصد (اختیاری)
        text = event.pattern_match.group(2)         # متن برای ترجمه
        
        if not text:
            await event.reply(
                "🌐 **دستور ترجمه**\n\n"
                "`.tr [متن]` → ترجمه خودکار به فارسی\n"
                "`.tr en [متن]` → ترجمه به انگلیسی\n"
                "`.tr fa [متن]` → ترجمه به فارسی\n"
                "`.tr [کد زبان] [متن]` → ترجمه به زبان دلخواه\n\n"
                "کدهای زبان: `en`, `fa`, `fr`, `de`, `es`, `ru`, `ar`, `tr`, `zh`"
            )
            return
        
        # زبان پیش‌فرض: فارسی
        if not target_lang:
            target_lang = "fa"
        
        thinking_msg = await event.reply(f"🔄 در حال ترجمه به `{target_lang}`...")
        
        try:
            system_prompt = f"تو یک مترجم حرفه‌ای هستی. متن زیر رو به زبان `{target_lang}` ترجمه کن. فقط متن ترجمه شده رو برگردان، هیچ توضیح اضافه‌ای نده."
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ]
            
            answer, status_code, error_text = get_groq_response(messages)
            
            if not answer:
                await thinking_msg.edit(f"❌ خطا: {status_code}")
                return
            
            final_msg = f"🌐 **ترجمه ({target_lang}):**\n\n{answer}"
            await thinking_msg.edit(final_msg)
            log_ai(f"✅ ترجمه به {target_lang}: {answer[:100]}...")
            
        except Exception as e:
            await thinking_msg.edit(f"❌ خطا: {str(e)}")
            log_ai(f"❌ خطا: {e}")
