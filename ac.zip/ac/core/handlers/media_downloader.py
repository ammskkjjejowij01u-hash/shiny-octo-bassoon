import os
import re
import asyncio
import aiohttp
import yt_dlp
from urllib.parse import quote, urlparse
from telethon import events

DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

YDL_OPTS_BASE = {
    'quiet': True, 'no_warnings': True, 'noplaylist': True, 'extract_flat': False,
    'ignoreerrors': True, 'no_check_certificate': True,
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'add_header': [('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
                   ('Accept-Language', 'en-us,en;q=0.5'),
                   ('Sec-Fetch-Mode', 'navigate')],
    'socket_timeout': 30, 'retries': 5, 'fragment_retries': 5,
}

def format_size(bytes):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes < 1024.0:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.1f} TB"

def is_direct_link(url):
    parsed = urlparse(url)
    path = parsed.path
    direct_extensions = [
        '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
        '.mp3', '.wav', '.flac', '.aac', '.ogg',
        '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg',
        '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2',
        '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
        '.apk', '.exe', '.msi', '.deb', '.rpm', '.iso'
    ]
    for ext in direct_extensions:
        if path.lower().endswith(ext):
            return True
    return False

def get_platform(url):
    url_lower = url.lower()
    if 'pinterest.com' in url_lower:
        return 'Pinterest'
    elif 'tiktok.com' in url_lower:
        return 'TikTok'
    elif 'instagram.com' in url_lower:
        return 'Instagram'
    else:
        return 'سایر'

def get_file_size_mb(file_path):
    try:
        return os.path.getsize(file_path) / (1024 * 1024)
    except:
        return 0

def extract_filename_from_url(url):
    parsed = urlparse(url)
    path = parsed.path
    filename = os.path.basename(path)
    if not filename or '.' not in filename:
        query_params = parsed.query
        if 'filename=' in query_params:
            match = re.search(r'filename=([^&]+)', query_params)
            if match:
                filename = match.group(1)
    if not filename:
        import time
        filename = f"download_{int(time.time())}.file"
    return filename

async def get_media_info_ytdlp(url):
    try:
        ydl_opts = {'quiet': True, 'no_warnings': True, 'extract_flat': False, 'noplaylist': True,
                    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                    'ignoreerrors': True, 'no_check_certificate': True}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                return None, "اطلاعات دریافت نشد"
            title = info.get('title', 'Unknown')
            duration = info.get('duration', 0)
            formats = info.get('formats', [])
            best_height = 0
            best_size = 0
            for f in formats:
                height = f.get('height')
                if height and f.get('vcodec') != 'none':
                    if height > best_height:
                        best_height = height
                        best_size = f.get('filesize') or f.get('filesize_approx')
            return {'title': title, 'duration': duration, 'best_height': best_height,
                    'best_size': best_size, 'best_size_human': format_size(best_size) if best_size else 'نامشخص',
                    'duration_min': duration // 60, 'duration_sec': duration % 60}, None
    except Exception as e:
        return None, f"خطا در دریافت اطلاعات: {str(e)}"

async def download_media_ytdlp(url):
    ydl_opts = {**YDL_OPTS_BASE, 'format': 'bestvideo+bestaudio/best', 'merge_output_format': 'mp4',
                'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s.%(ext)s')}
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            file_path = ydl.prepare_filename(info)
            if not os.path.exists(file_path):
                base = os.path.splitext(file_path)[0]
                for ext in ['.mp4', '.mkv', '.webm', '.mp3', '.m4a']:
                    test_path = base + ext
                    if os.path.exists(test_path):
                        file_path = test_path
                        break
            return file_path, info.get('title', 'Unknown')
    except Exception as e:
        return None, str(e)

async def download_direct_file(url):
    try:
        filename = extract_filename_from_url(url)
        if '.' not in filename:
            async with aiohttp.ClientSession() as session:
                async with session.head(url, timeout=10, allow_redirects=True) as response:
                    if response.status == 200:
                        content_disposition = response.headers.get('Content-Disposition', '')
                        if 'filename=' in content_disposition:
                            match = re.search(r'filename="?([^";]+)"?', content_disposition)
                            if match:
                                filename = match.group(1).strip()
                        if not filename or '.' not in filename:
                            content_type = response.headers.get('Content-Type', '')
                            ext_map = {'application/zip': '.zip', 'application/x-zip-compressed': '.zip',
                                       'application/x-rar-compressed': '.rar', 'application/x-7z-compressed': '.7z',
                                       'application/pdf': '.pdf', 'image/jpeg': '.jpg', 'image/png': '.png',
                                       'image/gif': '.gif', 'video/mp4': '.mp4', 'video/x-matroska': '.mkv',
                                       'audio/mpeg': '.mp3', 'application/octet-stream': '.bin'}
                            ext = ext_map.get(content_type, '')
                            if ext and filename and not filename.endswith(ext):
                                filename += ext
                            elif ext and not filename:
                                import time
                                filename = f"download_{int(time.time())}{ext}"
        if filename and '.' not in filename:
            filename += '.file'
        elif not filename:
            import time
            filename = f"download_{int(time.time())}.file"
        file_path = os.path.join(DOWNLOAD_FOLDER, filename)
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status != 200:
                    return None, f"HTTP Error {response.status}"
                with open(file_path, 'wb') as f:
                    async for chunk in response.content.iter_chunked(1024 * 1024):
                        f.write(chunk)
        return file_path, filename
    except Exception as e:
        return None, str(e)

async def wait_for_reply(client, user_id, reply_to_msg_id, timeout):
    future = asyncio.get_event_loop().create_future()
    @client.on(events.NewMessage(from_users=user_id))
    async def handler(event):
        if event.message.reply_to and event.message.reply_to.reply_to_msg_id == reply_to_msg_id:
            if not future.done():
                future.set_result(event.message)
                client.remove_event_handler(handler)
    try:
        return await asyncio.wait_for(future, timeout=timeout)
    except asyncio.TimeoutError:
        return None
    finally:
        try:
            client.remove_event_handler(handler)
        except:
            pass

async def process_media_command(client, event, command, platform_name):
    if not event.sender_id == int(os.getenv('OWNER_ID', 0)):
        return
    user_id = event.sender_id
    chat_id = event.chat_id
    args = event.pattern_match.group(1)
    if not args:
        await event.edit(f"🎬 **دستور دانلود از {platform_name}**\n\n.{command} [لینک] - لینک مورد نظر را بفرستید.\n\nمثال:\n.{command} https://www.{platform_name.lower()}.com/...\n.{command} https://example.com/file.zip")
        return
    url = args.strip()
    if not url.startswith(('http://', 'https://')):
        await event.edit("❌ لینک وارد شده معتبر نیست. لطفاً با `http://` یا `https://` شروع کنید.")
        return
    await event.delete()
    main_msg = await client.send_message(chat_id, "🔄 در حال دریافت اطلاعات...")
    is_direct = is_direct_link(url)
    if is_direct:
        await main_msg.edit("📥 در حال دانلود فایل...")
        file_path, result = await download_direct_file(url)
        if not file_path:
            await main_msg.edit(f"❌ خطا در دانلود:\n{result}")
            return
        file_size_mb = get_file_size_mb(file_path)
        file_name = os.path.basename(file_path)
        if file_size_mb > 2000:
            await main_msg.edit(f"⚠️ حجم فایل ({file_size_mb:.1f}MB) از حد مجاز تلگرام بیشتر است.")
            try:
                os.remove(file_path)
            except:
                pass
            return
        await main_msg.edit(f"✅ دانلود شد!\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n\n✅ **روی این پیام ریپلای کنید و یکی از گزینه‌های زیر را بنویسید:**\n• `لینک` - دریافت لینک دانلود در پیوی (معتبر ۲۴ ساعت)\n• `فایل` - دریافت خود فایل در همین چت")
        reply = await wait_for_reply(client, user_id, main_msg.id, 120)
        if not reply:
            await main_msg.edit("⏰ زمان انتخاب به پایان رسید. درخواست لغو شد.")
            try:
                os.remove(file_path)
            except:
                pass
            return
        choice = reply.text.strip().lower()
        await reply.delete()
        if choice not in ['لینک', 'فایل']:
            await main_msg.edit("❌ گزینه نامعتبر. لطفاً `لینک` یا `فایل` را وارد کنید.")
            try:
                os.remove(file_path)
            except:
                pass
            return
        public_host = os.getenv("PUBLIC_HOST", "185.183.33.91")
        port = os.getenv("PORT", "8800")
        encoded_filename = quote(file_name)
        download_link = f"http://{public_host}:{port}/files/{encoded_filename}"
        if choice == 'لینک':
            await client.send_message(user_id, f"🔗 **لینک دانلود فایل:**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n🔗 {download_link}\n\n⏳ لینک تا ۲۴ ساعت معتبر است.")
            await main_msg.edit(f"✅ لینک دانلود به پیوی شما ارسال شد.")
        else:
            await main_msg.edit(f"📤 در حال ارسال فایل...\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
            try:
                await client.send_file(chat_id, file_path, caption=f"📥 **دانلود شد!**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
                await main_msg.edit(f"✅ دانلود و ارسال شد!\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
                try:
                    os.remove(file_path)
                except:
                    pass
            except Exception as e:
                await main_msg.edit(f"❌ خطا در ارسال فایل:\n{e}")
        return
    info, err = await get_media_info_ytdlp(url)
    if not info:
        await main_msg.edit(f"❌ خطا در دریافت اطلاعات: {err or 'نامشخص'}")
        return
    msg = f"🎬 **{info['title']}**\n⏱️ مدت: {info['duration_min']}:{info['duration_sec']:02d}\n📦 حجم تقریبی: {info['best_size_human']}\n📱 پلتفرم: {platform_name}\n\n✅ **روی این پیام ریپلای کنید و یکی از گزینه‌های زیر را بنویسید:**\n• `لینک` - دریافت لینک دانلود در پیوی (معتبر ۲۴ ساعت)\n• `فایل` - دریافت خود فایل در همین چت"
    await main_msg.edit(msg)
    reply = await wait_for_reply(client, user_id, main_msg.id, 120)
    if not reply:
        await main_msg.edit("⏰ زمان انتخاب به پایان رسید. درخواست لغو شد.")
        return
    choice = reply.text.strip().lower()
    await reply.delete()
    if choice not in ['لینک', 'فایل']:
        await main_msg.edit("❌ گزینه نامعتبر. لطفاً `لینک` یا `فایل` را وارد کنید.")
        return
    await main_msg.edit("📥 در حال دانلود... لطفاً صبر کنید...")
    file_path, result = await download_media_ytdlp(url)
    if not file_path:
        await main_msg.edit(f"❌ خطا در دانلود:\n{result}")
        return
    file_size_mb = get_file_size_mb(file_path)
    file_name = os.path.basename(file_path)
    if file_size_mb > 2000:
        await main_msg.edit(f"⚠️ حجم فایل از حد مجاز تلگرام بیشتر است.")
        try:
            os.remove(file_path)
        except:
            pass
        return
    public_host = os.getenv("PUBLIC_HOST", "185.183.33.91")
    port = os.getenv("PORT", "8800")
    encoded_filename = quote(file_name)
    download_link = f"http://{public_host}:{port}/files/{encoded_filename}"
    if choice == 'لینک':
        await client.send_message(user_id, f"🔗 **لینک دانلود فایل:**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB\n🔗 {download_link}\n\n⏳ لینک تا ۲۴ ساعت معتبر است.")
        await main_msg.edit(f"✅ لینک دانلود به پیوی شما ارسال شد.")
    else:
        await main_msg.edit(f"📤 در حال ارسال فایل...\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
        try:
            await client.send_file(chat_id, file_path, caption=f"📥 **دانلود شد!**\n📁 {file_name}\n📦 {file_size_mb:.1f} MB", supports_streaming=True)
            await main_msg.edit(f"✅ دانلود و ارسال شد!\n📁 {file_name}\n📦 {file_size_mb:.1f} MB")
            try:
                os.remove(file_path)
            except:
                pass
        except Exception as e:
            await main_msg.edit(f"❌ خطا در ارسال فایل:\n{e}")

def register_media_downloader(client, db):
    @client.on(events.NewMessage(pattern=r'\.pt(?: (.+))?$'))
    async def pt_command(event):
        await process_media_command(client, event, 'pt', 'Pinterest')
    @client.on(events.NewMessage(pattern=r'\.tt(?: (.+))?$'))
    async def tt_command(event):
        await process_media_command(client, event, 'tt', 'TikTok')
    @client.on(events.NewMessage(pattern=r'\.ig(?: (.+))?$'))
    async def ig_command(event):
        await process_media_command(client, event, 'ig', 'Instagram')
    @client.on(events.NewMessage(pattern=r'\.al(?: (.+))?$'))
    async def al_command(event):
        await process_media_command(client, event, 'al', 'سایر')
