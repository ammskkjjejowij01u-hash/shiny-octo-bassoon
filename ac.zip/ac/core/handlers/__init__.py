from .auto_catch import register_auto_catch
from .admin import register_admin
from .selector import register_selector
from .advanced import register_advanced
from .dice import register_dice
from .casino import register_casino
from .yt_downloader import register_yt_downloader
from .media_downloader import register_media_downloader
from .ai_handler import register_ai_handler
from .farming import register_farming
from .translator import register_translator
from .summarizer import register_summarizer
from .scheduler import register_scheduler
from .tools import register_tools  # ← اضافه کن

def register_handlers(client, db):
    register_auto_catch(client, db)
    register_admin(client, db)
    register_selector(client, db)
    register_advanced(client, db)
    register_dice(client, db)
    register_casino(client, db)
    register_yt_downloader(client, db)
    register_media_downloader(client, db)
    register_ai_handler(client, db)
    register_farming(client, db)
    register_translator(client, db)
    register_summarizer(client, db)
    register_scheduler(client, db)
    register_tools(client, db)  # ← اضافه کن
