import json
import os
import hashlib
import redis
from typing import Optional, Dict, Any

class Database:
    def __init__(self, db_file=None, use_redis=True):
        # پیدا کردن مسیر دیتابیس
        if db_file is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_file = os.path.join(base_dir, "data", "full_database.json")
        
        self.db_file = db_file
        self.data = {}
        self.use_redis = use_redis
        self.redis_client = None
        
        # اتصال به Redis
        if use_redis:
            try:
                self.redis_client = redis.Redis(
                    host='localhost',
                    port=6379,
                    db=0,
                    decode_responses=True,
                    socket_connect_timeout=2,
                    socket_timeout=2
                )
                # تست اتصال
                self.redis_client.ping()
                print("✅ Redis connected successfully!")
                
                # چک کردن اینکه آیا دیتا توی Redis هست یا نه
                if not self.redis_client.exists("db:version"):
                    print("🔄 Redis is empty, loading from JSON...")
                    self._load_to_redis()
                else:
                    print("📦 Redis already has data, skipping load.")
                    # فقط برای نمایش تعداد، از Redis می‌خونیم
                    count = self.redis_client.scard("db:all_ids")
                    print(f"✅ {count} کاراکتر در Redis موجود است")
                    
            except Exception as e:
                print(f"⚠️ Redis connection failed: {e}")
                print("📂 Falling back to JSON only")
                self.use_redis = False
                self.redis_client = None
                self.load()
        
        # اگر Redis فعال نباشه، از JSON استفاده کن
        if not self.use_redis:
            self.load()
    
    def _load_to_redis(self):
        """بارگذاری دیتابیس JSON به Redis"""
        if not self.redis_client:
            return
        
        self.load()
        
        # پاک کردن Redis قبل از بارگذاری
        self.redis_client.flushdb()
        print("🗑️ Redis flushed, loading data...")
        
        # ذخیره هر کاراکتر به صورت هش در Redis
        pipe = self.redis_client.pipeline()
        for char_id, char_data in self.data.items():
            key = f"char:{char_id}"
            pipe.hset(key, mapping=char_data)
            # ایندکس‌های کمکی
            if char_data.get("file_unique_id"):
                pipe.set(f"uid:{char_data['file_unique_id']}", char_id)
            if char_data.get("hash"):
                pipe.set(f"hash:{char_data['hash']}", char_id)
            pipe.sadd("db:all_ids", char_id)
        
        pipe.set("db:version", "1.0")
        pipe.set("db:count", len(self.data))
        pipe.execute()
        
        print(f"✅ {len(self.data)} کاراکتر به Redis منتقل شد")
    
    def load(self):
        """بارگذاری از فایل JSON (در صورت نیاز)"""
        print(f"📂 مسیر جستجوی دیتابیس: {self.db_file}")
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, "r") as f:
                    self.data = json.load(f)
                print(f"✅ {len(self.data)} کاراکتر بارگذاری شد")
            except Exception as e:
                print(f"❌ خطا در خواندن دیتابیس: {e}")
                self.data = {}
        else:
            print(f"❌ فایل دیتابیس پیدا نشد: {self.db_file}")
    
    def get_by_unique_id(self, file_unique_id: str) -> Optional[Dict[str, Any]]:
        """جستجو با file_unique_id (اول Redis، بعد JSON)"""
        # اگر Redis فعال باشه، اول از Redis می‌گیریم
        if self.use_redis and self.redis_client:
            try:
                char_id = self.redis_client.get(f"uid:{file_unique_id}")
                if char_id:
                    char_data = self.redis_client.hgetall(f"char:{char_id}")
                    if char_data:
                        return char_data
            except Exception as e:
                print(f"⚠️ Redis error in get_by_unique_id: {e}")
        
        # Fallback به JSON
        for char_id, char_data in self.data.items():
            if char_data.get("file_unique_id") == file_unique_id:
                return char_data
        return None
    
    def get_by_hash(self, media_data: bytes) -> Optional[Dict[str, Any]]:
        """جستجو با هش (اول Redis، بعد JSON)"""
        h = hashlib.md5(media_data).hexdigest()
        
        # اگر Redis فعال باشه، اول از Redis می‌گیریم
        if self.use_redis and self.redis_client:
            try:
                char_id = self.redis_client.get(f"hash:{h}")
                if char_id:
                    char_data = self.redis_client.hgetall(f"char:{char_id}")
                    if char_data:
                        return char_data
            except Exception as e:
                print(f"⚠️ Redis error in get_by_hash: {e}")
        
        # Fallback به JSON
        for char_data in self.data.values():
            if char_data.get("hash") == h:
                return char_data
        return None
    
    def reload(self):
        """بارگذاری مجدد دیتابیس (وقتی فایل تغییر کرد)"""
        self.load()
        if self.use_redis and self.redis_client:
            self._load_to_redis()
    
    def get_all(self) -> Dict[str, Dict[str, Any]]:
        """دریافت کل دیتابیس"""
        return self.data
    
    def get_count(self) -> int:
        """تعداد کاراکترها"""
        if self.use_redis and self.redis_client:
            try:
                count = self.redis_client.get("db:count")
                if count:
                    return int(count)
            except:
                pass
        return len(self.data)
    
    def close(self):
        """بستن اتصال Redis"""
        if self.redis_client:
            self.redis_client.close()
