"""Core module for the userbot"""
