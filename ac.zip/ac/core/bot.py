from telethon import TelegramClient
from telethon.sessions import StringSession
from core.config import Config
from core.database import Database
from core.handlers import register_handlers
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Userbot:
    def __init__(self):
        self.client = TelegramClient(
            StringSession(Config.STRING_SESSION),
            Config.API_ID,
            Config.API_HASH
        )
        # ===== استفاده از Redis (فعال) =====
        self.db = Database(use_redis=True)
    
    async def start(self):
        await self.client.start()
        register_handlers(self.client, self.db)
        logger.info("🚀 Userbot started!")
        await self.client.run_until_disconnected()
