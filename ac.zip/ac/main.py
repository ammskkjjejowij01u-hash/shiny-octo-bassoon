#!/usr/bin/env python3
import os
import sys
import json
import asyncio
import threading
import subprocess
import signal
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

# ========== FastAPI ==========
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn

# ========== uvloop (افزایش سرعت) ==========
try:
    import uvloop
    uvloop_available = True
except ImportError:
    uvloop_available = False
    print("⚠️ uvloop نصب نیست! برای نصب: pip install uvloop")

sys.path.insert(0, os.path.dirname(__file__))
from core.bot import Userbot

# ========== تنظیمات ==========
DOWNLOAD_FOLDER = "downloads"
CLEANUP_AFTER_HOURS = 24
METADATA_FILE = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# ========== مسیر Redis (تنظیم شده برای Termux) ==========
REDIS_SERVER = "/data/data/com.termux/files/usr/bin/redis-server"
REDIS_CONF = os.path.expanduser("~/redis/redis.conf")

# اگه فایل کانفیگ وجود نداره، از پیش‌فرض استفاده کن
if not os.path.exists(REDIS_CONF):
    # ایجاد فایل کانفیگ پیش‌فرض
    os.makedirs(os.path.dirname(REDIS_CONF), exist_ok=True)
    with open(REDIS_CONF, 'w') as f:
        f.write("""daemonize no
port 6379
bind 127.0.0.1
save ""
appendonly no
""")
    print(f"✅ Redis config created at: {REDIS_CONF}")

print(f"✅ Redis server: {REDIS_SERVER}")
print(f"✅ Redis config: {REDIS_CONF}")

# ========== توابع FastAPI ==========
def load_metadata():
    if os.path.exists(METADATA_FILE):
        try:
            with open(METADATA_FILE, "r") as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_metadata(meta):
    with open(METADATA_FILE, "w") as f:
        json.dump(meta, f, indent=4)

def cleanup_old_files():
    meta = load_metadata()
    now = datetime.now()
    to_delete = []
    
    for filename, upload_time in meta.items():
        try:
            upload_dt = datetime.fromisoformat(upload_time)
            if now - upload_dt > timedelta(hours=CLEANUP_AFTER_HOURS):
                to_delete.append(filename)
        except:
            to_delete.append(filename)
    
    for filename in to_delete:
        file_path = os.path.join(DOWNLOAD_FOLDER, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"🗑️ فایل قدیمی حذف شد: {filename}")
            except:
                pass
        if filename in meta:
            del meta[filename]
    
    if to_delete:
        save_metadata(meta)
    return len(to_delete)

@asynccontextmanager
async def lifespan(app: FastAPI):
    cleanup_old_files()
    print("🚀 FastAPI File Server started!")
    yield

app = FastAPI(
    title="Userbot File Server",
    version="2.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/files", StaticFiles(directory=DOWNLOAD_FOLDER), name="files")

@app.get("/")
async def index():
    return JSONResponse({
        "status": "File server is running",
        "version": "2.0",
        "endpoints": {
            "/": "Server status",
            "/status": "Storage usage",
            "/list": "List all files",
            "/files/<filename>": "Download a file (static)",
        }
    })

@app.get("/status")
async def status():
    total_size = 0
    files_count = 0
    
    if os.path.exists(DOWNLOAD_FOLDER):
        for f in os.listdir(DOWNLOAD_FOLDER):
            f_path = os.path.join(DOWNLOAD_FOLDER, f)
            if f != "files_meta.json" and os.path.isfile(f_path):
                total_size += os.path.getsize(f_path)
                files_count += 1
    
    def format_size(bytes):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes < 1024.0:
                return f"{bytes:.1f} {unit}"
            bytes /= 1024.0
        return f"{bytes:.1f} TB"
    
    return JSONResponse({
        "files_count": files_count,
        "total_size_bytes": total_size,
        "total_size_human": format_size(total_size),
        "download_folder": DOWNLOAD_FOLDER
    })

@app.get("/list")
async def list_files():
    cleanup_old_files()
    
    if not os.path.exists(DOWNLOAD_FOLDER):
        return JSONResponse({"files": [], "count": 0})
    
    files = os.listdir(DOWNLOAD_FOLDER)
    files = [f for f in files if f != "files_meta.json" and os.path.isfile(os.path.join(DOWNLOAD_FOLDER, f))]
    
    result = []
    for f in files:
        f_path = os.path.join(DOWNLOAD_FOLDER, f)
        size = os.path.getsize(f_path) if os.path.exists(f_path) else 0
        mtime = datetime.fromtimestamp(os.path.getmtime(f_path)).isoformat() if os.path.exists(f_path) else None
        result.append({
            "filename": f,
            "size_bytes": size,
            "size_mb": round(size / (1024 * 1024), 2),
            "modified": mtime
        })
    
    return JSONResponse({
        "files": result,
        "count": len(result)
    })

def run_fastapi():
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8800,
        log_level="warning",
        access_log=False,
        workers=1,
        timeout_keep_alive=120,
        limit_max_requests=1000,
        limit_concurrency=100,
        ws=None,
    )

# ========== مدیریت Redis ==========
def start_redis():
    """اجرای Redis به عنوان زیرپروسه"""
    if not os.path.exists(REDIS_SERVER):
        print(f"⚠️ Redis not found at: {REDIS_SERVER}")
        return None
    
    try:
        # استفاده از preexec_fn برای لینوکس (و Termux)
        process = subprocess.Popen(
            [REDIS_SERVER, REDIS_CONF],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=os.setsid if hasattr(os, 'setsid') else None
        )
        print(f"✅ Redis started (PID: {process.pid})")
        return process
    except Exception as e:
        print(f"❌ Failed to start Redis: {e}")
        return None

def stop_redis(process):
    """متوقف کردن Redis"""
    if not process:
        return
    
    try:
        if hasattr(os, 'killpg') and hasattr(process, 'pid'):
            os.killpg(os.getpgid(process.pid), signal.SIGTERM)
        else:
            process.terminate()
        process.wait(timeout=5)
        print("🛑 Redis stopped")
    except subprocess.TimeoutExpired:
        try:
            if hasattr(os, 'killpg') and hasattr(process, 'pid'):
                os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            else:
                process.kill()
            print("🛑 Redis killed (force)")
        except:
            pass
    except Exception as e:
        print(f"⚠️ Error stopping Redis: {e}")

# ========== Main ==========
async def main():
    # ===== ۱. اجرای Redis به عنوان زیرپروسه =====
    redis_process = start_redis()
    
    # ===== ۲. اجرای FastAPI در یک ترد جداگانه =====
    server_thread = threading.Thread(target=run_fastapi, daemon=True)
    server_thread.start()
    print("🌐 FastAPI File server running on http://0.0.0.0:8800")
    print("📖 Swagger UI: http://0.0.0.0:8800/docs")
    print("📁 Static files: http://0.0.0.0:8800/files/<filename>")
    
    # ===== ۳. اجرای یوزربات =====
    try:
        bot = Userbot()
        await bot.start()
    except KeyboardInterrupt:
        print("\n🔄 Shutting down...")
    finally:
        # ===== ۴. متوقف کردن Redis بعد از بسته شدن یوزربات =====
        stop_redis(redis_process)

if __name__ == "__main__":
    # ===== استفاده از uvloop (در صورت نصب) =====
    if uvloop_available:
        uvloop.install()
        print("⚡ uvloop enabled (faster async)")
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
