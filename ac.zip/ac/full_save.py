#!/usr/bin/env python3
"""
Script for backing up all private chats (PVs) of the userbot account.
Run with: python full_save.py
This script is for owner-only and runs in terminal.
"""

import os
import sys
import json
import asyncio
import shutil
import time
from datetime import datetime
from pathlib import Path
from telethon import TelegramClient
from telethon.tl.types import (
    MessageMediaPhoto, MessageMediaDocument, MessageMediaWebPage,
    MessageMediaDice, MessageMediaPoll, MessageMediaContact
)
from telethon.errors import FloodWaitError

# ========== تنظیمات ==========
# بارگذاری از .env
from dotenv import load_dotenv
load_dotenv()

API_ID = int(os.getenv("API_ID", 0))
API_HASH = os.getenv("API_HASH", "")
STRING_SESSION = os.getenv("STRING_SESSION", "")

if not API_ID or not API_HASH or not STRING_SESSION:
    print("❌ لطفاً API_ID, API_HASH و STRING_SESSION را در فایل .env تنظیم کنید.")
    sys.exit(1)

SAVE_ROOT = "save"
MESSAGES_PER_FILE = 2000
MEDIA_TYPES = {
    'photo': 'photo',
    'video': 'video',
    'voice': 'voice',
    'audio': 'audio',
    'sticker': 'sticker',
    'gif': 'gif',
    'document': 'document'
}

# ========== کلاس کمکی ==========
class ProgressTracker:
    def __init__(self, total):
        self.total = total
        self.current = 0
        self.start_time = time.time()
    
    def update(self, step=1):
        self.current += step
        percent = (self.current / self.total) * 100
        elapsed = time.time() - self.start_time
        remaining = (elapsed / self.current) * (self.total - self.current) if self.current > 0 else 0
        print(f"\r⏳ پیشرفت: {self.current}/{self.total} ({percent:.1f}%) | زمان باقی: {self._format_time(remaining)}", end="")
    
    def _format_time(self, seconds):
        if seconds < 60:
            return f"{int(seconds)} ثانیه"
        elif seconds < 3600:
            return f"{int(seconds//60)} دقیقه {int(seconds%60)} ثانیه"
        else:
            return f"{int(seconds//3600)} ساعت {int((seconds%3600)//60)} دقیقه"
    
    def finish(self):
        elapsed = time.time() - self.start_time
        print(f"\n✅ انجام شد! زمان کل: {self._format_time(elapsed)}")

def get_media_type(message):
    """تشخیص نوع مدیا برای نام‌گذاری"""
    if not message.media:
        return None
    
    if message.photo:
        return 'photo'
    if message.video:
        return 'video'
    if message.voice:
        return 'voice'
    if message.audio:
        return 'audio'
    if message.sticker:
        return 'sticker'
    if message.gif:
        return 'gif'
    if message.document:
        # بررسی document برای تشخیص
        if message.media.document and message.media.document.mime_type:
            mime = message.media.document.mime_type
            if 'video' in mime:
                return 'video'
            if 'image' in mime:
                return 'photo'
        return 'document'
    return None

def get_media_extension(message):
    """دریافت پسوند مناسب برای فایل مدیا"""
    mime_type = None
    if hasattr(message.media, 'document') and message.media.document:
        mime_type = message.media.document.mime_type
    
    if not mime_type:
        if message.photo:
            return '.jpg'
        if message.video:
            return '.mp4'
        if message.voice:
            return '.ogg'
        if message.audio:
            return '.mp3'
        if message.sticker:
            return '.webp'
        if message.gif:
            return '.gif'
        return '.bin'
    
    ext_map = {
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/gif': '.gif',
        'image/webp': '.webp',
        'video/mp4': '.mp4',
        'video/quicktime': '.mov',
        'audio/ogg': '.ogg',
        'audio/mpeg': '.mp3',
        'audio/mp4': '.m4a',
        'application/octet-stream': '.bin'
    }
    return ext_map.get(mime_type, '.bin')

def safe_filename(text, max_len=50):
    """ایجاد نام فایل امن از متن"""
    import re
    # حذف کاراکترهای ممنوعه
    text = re.sub(r'[\\/*?:"<>|\s]', '_', text)
    return text[:max_len]

async def download_media_safe(client, message, save_path):
    """دانلود مدیا با مدیریت خطا"""
    if not message.media:
        return None
    
    try:
        ext = get_media_extension(message)
        msg_id = message.id
        # نام فایل: msg_{id}_{type}{ext}
        media_type = get_media_type(message) or 'media'
        filename = f"msg_{msg_id}_{media_type}{ext}"
        filepath = os.path.join(save_path, filename)
        
        # اگر فایل وجود داشت، دانلود نکن
        if os.path.exists(filepath):
            return filepath
        
        await client.download_media(message, file=filepath)
        return filepath
    except Exception as e:
        print(f"\n⚠️ خطا در دانلود مدیا (msg {message.id}): {e}")
        return None

def format_message_text(message):
    """فرمت‌کردن متن پیام برای نمایش"""
    text = message.text or ""
    if message.fwd_from:
        text = f"[Forwarded]\n{text}"
    if message.reply_to:
        text = f"[Reply to msg {message.reply_to.reply_to_msg_id}]\n{text}"
    return text

def build_html(all_messages, chat_name, output_dir):
    """ساخت فایل HTML برای نمایش پیام‌ها"""
    html_template = """<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بکاپ پیوی - {chat_name}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; padding: 20px; }}
        .container {{ max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 20px; }}
        .header {{ text-align: center; padding: 20px 0; border-bottom: 2px solid #e0e0e0; margin-bottom: 20px; }}
        .header h1 {{ color: #1a73e8; font-size: 24px; }}
        .header .info {{ color: #666; font-size: 14px; margin-top: 5px; }}
        .message {{ background: #f8f9fa; border-radius: 8px; padding: 12px 16px; margin-bottom: 12px; border-left: 4px solid #1a73e8; }}
        .message .sender {{ font-weight: bold; color: #1a73e8; }}
        .message .date {{ color: #888; font-size: 12px; margin-right: 10px; }}
        .message .text {{ margin-top: 6px; white-space: pre-wrap; word-break: break-word; }}
        .message .media {{ margin-top: 10px; }}
        .message .media img, .message .media video, .message .media audio {{ max-width: 100%; border-radius: 8px; }}
        .message .media .sticker {{ max-width: 128px; }}
        .footer {{ text-align: center; margin-top: 20px; color: #888; font-size: 12px; }}
        .msg-id {{ color: #aaa; font-size: 11px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📁 بکاپ پیوی: {chat_name}</h1>
            <div class="info">تعداد پیام‌ها: {total_messages} | تاریخ: {date}</div>
        </div>
        <div id="messages">
            {messages_html}
        </div>
        <div class="footer">
            ساخته شده توسط یوزربات | {date}
        </div>
    </div>
</body>
</html>"""
    
    messages_html = []
    for msg in all_messages:
        msg_id = msg.get('id', '')
        date = msg.get('date', '')
        text = msg.get('text', '').replace('\n', '<br>')
        media_html = ""
        media_files = msg.get('media_files', [])
        for mf in media_files:
            path = mf.get('path', '')
            media_type = mf.get('type', '')
            if os.path.exists(path):
                rel_path = os.path.basename(path)
                if media_type in ['photo', 'sticker']:
                    media_html += f'<img src="{rel_path}" class="sticker" /><br>'
                elif media_type in ['video']:
                    media_html += f'<video controls><source src="{rel_path}"></video><br>'
                elif media_type in ['voice', 'audio']:
                    media_html += f'<audio controls><source src="{rel_path}"></audio><br>'
                else:
                    media_html += f'<a href="{rel_path}">📎 دانلود فایل</a><br>'
        
        msg_html = f"""
        <div class="message">
            <div class="sender">پیام #{msg_id}</div>
            <span class="date">{date}</span>
            <div class="text">{text}</div>
            <div class="media">{media_html}</div>
        </div>
        """
        messages_html.append(msg_html)
    
    final_html = html_template.format(
        chat_name=chat_name,
        total_messages=len(all_messages),
        date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        messages_html='\n'.join(messages_html)
    )
    
    index_path = os.path.join(output_dir, "index.html")
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(final_html)
    return index_path

async def save_dialog(client, dialog, save_path):
    """ذخیره‌سازی کامل یک دیالوگ (پیوی)"""
    print(f"\n📂 در حال بکاپ‌گیری از: {dialog.name} (ID: {dialog.id})")
    
    # ایجاد پوشه‌ی دیالوگ
    dialog_folder = os.path.join(save_path, safe_filename(dialog.name or str(dialog.id)))
    os.makedirs(dialog_folder, exist_ok=True)
    
    # پوشه‌ی مدیا
    media_folder = os.path.join(dialog_folder, "media")
    os.makedirs(media_folder, exist_ok=True)
    
    # دریافت پیام‌ها
    all_messages = []
    total_count = 0
    offset_id = 0
    file_count = 0
    media_saved = 0
    
    print("🔄 دریافت پیام‌ها... (این کار ممکن است زمان‌بر باشد)")
    
    while True:
        try:
            messages = await client.get_messages(dialog.id, offset_id=offset_id, limit=2000, reverse=False)
            if not messages:
                break
            
            # ذخیره این بسته
            batch_messages = []
            for msg in messages:
                # اطلاعات پایه
                msg_data = {
                    'id': msg.id,
                    'date': msg.date.isoformat() if msg.date else None,
                    'text': format_message_text(msg),
                    'media_files': []
                }
                
                # دانلود مدیا
                if msg.media:
                    media_type = get_media_type(msg)
                    if media_type:
                        # نام فایل مدیا
                        ext = get_media_extension(msg)
                        filename = f"{msg.id}_{media_type}{ext}"
                        filepath = os.path.join(media_folder, filename)
                        
                        if not os.path.exists(filepath):
                            try:
                                await client.download_media(msg, file=filepath)
                                media_saved += 1
                            except Exception as e:
                                print(f"\n⚠️ خطا در دانلود msg {msg.id}: {e}")
                                filepath = None
                        
                        if filepath and os.path.exists(filepath):
                            msg_data['media_files'].append({
                                'path': filepath,
                                'type': media_type,
                                'filename': filename
                            })
                
                batch_messages.append(msg_data)
                total_count += 1
            
            all_messages.extend(batch_messages)
            file_count += 1
            
            # ذخیره به صورت JSON
            json_file = os.path.join(dialog_folder, f"messages_{file_count:04d}.json")
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(batch_messages, f, ensure_ascii=False, indent=2)
            
            print(f"💾 {file_count} فایل ذخیره شد | {total_count} پیام | {media_saved} مدیا")
            
            # آپدیت offset
            offset_id = messages[-1].id
            
            # اگر تعداد پیام‌ها کمتر از limit بود، یعنی تمام شده
            if len(messages) < 2000:
                break
                
            # جلوگیری از FloodWait
            await asyncio.sleep(0.5)
            
        except FloodWaitError as e:
            print(f"\n⏳ صبر کنید {e.seconds} ثانیه...")
            await asyncio.sleep(e.seconds + 1)
        except Exception as e:
            print(f"\n❌ خطا: {e}")
            break
    
    # ساخت HTML
    if all_messages:
        html_path = build_html(all_messages, dialog.name or str(dialog.id), dialog_folder)
        print(f"✅ HTML ساخته شد: {html_path}")
    
    return total_count, media_saved

async def main():
    print("="*50)
    print("📁 ابزار بکاپ کامل پیوی‌ها")
    print("="*50)
    
    # اتصال به حساب
    client = TelegramClient(STRING_SESSION, API_ID, API_HASH)
    await client.start()
    print("✅ متصل شد!")
    
    # دریافت دیالوگ‌های پیوی
    dialogs = await client.get_dialogs()
    pv_dialogs = [d for d in dialogs if d.is_user and not d.is_group and not d.is_channel]
    
    if not pv_dialogs:
        print("❌ هیچ پیوی‌ای پیدا نشد!")
        return
    
    print(f"\n🔹 لیست پیوی‌های موجود ({len(pv_dialogs)} مورد):")
    for i, d in enumerate(pv_dialogs, 1):
        name = d.name or f"ID:{d.id}"
        print(f"  {i}. {name} (ID: {d.id})")
    
    print("\n📌 شماره‌های مورد نظر را وارد کنید (مثلاً `1` یا `1 3 5` یا `0` برای همه):")
    choice = input("> ").strip()
    
    if not choice:
        print("❌ عددی وارد نشد.")
        return
    
    if choice == '0':
        selected = pv_dialogs
    else:
        try:
            indices = [int(x.strip()) for x in choice.split() if x.strip().isdigit()]
            selected = [pv_dialogs[i-1] for i in indices if 1 <= i <= len(pv_dialogs)]
        except:
            print("❌ ورودی نامعتبر.")
            return
    
    if not selected:
        print("❌ هیچ دیالوگی انتخاب نشد.")
        return
    
    print(f"\n✅ {len(selected)} دیالوگ انتخاب شد.")
    confirm = input("آیا ادامه می‌دهید؟ (y/n): ").strip().lower()
    if confirm != 'y':
        print("🚫 عملیات لغو شد.")
        return
    
    # ایجاد پوشه اصلی
    os.makedirs(SAVE_ROOT, exist_ok=True)
    session_folder = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_path = os.path.join(SAVE_ROOT, session_folder)
    os.makedirs(save_path, exist_ok=True)
    
    print(f"\n📁 ذخیره در: {save_path}")
    
    total_msgs = 0
    total_media = 0
    
    for dialog in selected:
        try:
            msgs, media = await save_dialog(client, dialog, save_path)
            total_msgs += msgs
            total_media += media
            print(f"✅ {dialog.name}: {msgs} پیام | {media} مدیا")
        except Exception as e:
            print(f"❌ خطا در {dialog.name}: {e}")
    
    print("\n" + "="*50)
    print(f"✅ عملیات بکاپ کامل شد!")
    print(f"📊 کل پیام‌ها: {total_msgs}")
    print(f"📊 کل مدیا: {total_media}")
    print(f"📁 مسیر: {save_path}")
    print("="*50)
    
    await client.disconnect()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 عملیات توسط کاربر متوقف شد.")
    except Exception as e:
        print(f"\n❌ خطا: {e}")
