import os
import json
import logging
from datetime import datetime, timedelta
from flask import Flask, send_from_directory, jsonify

app = Flask(__name__)

DOWNLOAD_FOLDER = "downloads"
CLEANUP_AFTER_HOURS = 24

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
METADATA_FILE = os.path.join(DOWNLOAD_FOLDER, "files_meta.json")

def load_metadata():
    if os.path.exists(METADATA_FILE):
        try:
            with open(METADATA_FILE, "r") as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_metadata(meta):
    with open(METADATA_FILE, "w") as f:
        json.dump(meta, f, indent=4)

def cleanup_old_files():
    meta = load_metadata()
    now = datetime.now()
    to_delete = []
    
    for filename, upload_time in meta.items():
        upload_dt = datetime.fromisoformat(upload_time)
        if now - upload_dt > timedelta(hours=CLEANUP_AFTER_HOURS):
            to_delete.append(filename)
    
    for filename in to_delete:
        file_path = os.path.join(DOWNLOAD_FOLDER, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"🗑️ فایل قدیمی حذف شد: {filename}")
            except:
                pass
        del meta[filename]
    
    if to_delete:
        save_metadata(meta)

@app.route('/<filename>')
def download_file(filename):
    cleanup_old_files()
    file_path = os.path.join(DOWNLOAD_FOLDER, filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404
    return send_from_directory(DOWNLOAD_FOLDER, filename, as_attachment=True)

@app.route('/files')
def list_files():
    cleanup_old_files()
    files = os.listdir(DOWNLOAD_FOLDER)
    files = [f for f in files if f != "files_meta.json"]
    return jsonify({"files": files, "count": len(files)})

@app.route('/')
def index():
    return jsonify({
        "status": "File server is running",
        "endpoints": {
            "/<filename>": "Download a file",
            "/files": "List all files"
        }
    })

if __name__ == '__main__':
    print("🚀 File server running on http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)
